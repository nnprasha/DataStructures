// Smoothsort3.cpp : Defines the entry point for the console application.
//

#include "SmoothSort.h"

//Initializes Leonardo heap
LeonardoHeap::LeonardoHeap()
{
	comparisonsCounter = 0;
}

//Starting point of SmoothSort
void LeonardoHeap::Init(vIterator beginPtr, vIterator endPtr, LeonardoHeap Lheap)
{
	if (beginPtr == endPtr || beginPtr + 1 == endPtr)
		return;	//if list is empty

	Lheap.rightMostTreeSize = 0; //Initially setting the smallest tree to size 0

								 //Inserting into the Heap
	for (vIterator iterator = beginPtr; iterator != endPtr; iterator++)
		InsertIntoHeap(beginPtr, iterator, endPtr, Lheap);

	//Dequeueing from Heap
	for (vIterator iterator = endPtr; iterator != beginPtr; --iterator)
		DeQ(beginPtr, iterator, Lheap);
}


//Returns true if ele 2 is larger than ele1
bool LeonardoHeap::comparator(int& element1,int& element2)
{
	comparisonsCounter++;	//incrementing the number of comparisons
	return element1 < element2;
}

//returns root of right subtree
vIterator LeonardoHeap::RightChild(vIterator rootElement)
{
	return rootElement - 1;
}

//returns root of left subtree
vIterator LeonardoHeap::LeftChild(vIterator rootElement, size_t sizeOfElement)
{
	return RightChild(rootElement) - LNumbers[sizeOfElement - 2];
}

//Returns root of the subtree with larger value
vIterator LeonardoHeap::LargerChild(vIterator rootElement, size_t sizeOfElement)
{
	vIterator left = LeftChild(rootElement, sizeOfElement);
	vIterator right = RightChild(rootElement);
	
	if (comparator(*left, *right))
	{//if right is bigger
		return right;
	}
	//left is bigger
	return left;
}

//Filtering the Heap and maintaining Leonardo Heap Property
void LeonardoHeap::FilterHeap(vIterator rootElement, size_t sizeOfElement)
{
	while (sizeOfElement > 1)
	{
		vIterator left = LeftChild(rootElement, sizeOfElement);	//iterator to left child
		vIterator right = RightChild(rootElement);	//iterator to right child
		vIterator larger; //Larger Child
		size_t cSize;	//Size of Child

		
		if (comparator(*left, *right))
		{//if right child is larger
			larger= right;
			cSize = sizeOfElement - 2;
		}
		else
		{//if left child is larger
			larger = left;
			cSize = sizeOfElement - 1;
		}

		
		if (comparator(*rootElement, *larger))
		{//if larger child is larger that root, we swap larger child and root
			iter_swap(rootElement, larger);
			rootElement = larger;
			sizeOfElement = cSize;
		}
		else
		{
			return;
		}	
	}
}

//MaxHeapify to maintain Heap Property
void LeonardoHeap::MaxHeapify(vIterator beginPtr, vIterator endPtr, LeonardoHeap Lheap)
{
	vIterator iterator = endPtr - 1;	//iterator pointing to last but one element
	size_t sizeOfLastHeap;
	while (true)
	{
		sizeOfLastHeap = Lheap.rightMostTreeSize;
		if (size_t(distance(beginPtr, iterator)) == LNumbers[sizeOfLastHeap] - 1)
			break;

		vIterator compareToMe = iterator; //one to compare with

		if (Lheap.rightMostTreeSize > 1)
		{	//if size of smallest tree is greater than 1

			vIterator large = LargerChild(iterator, Lheap.rightMostTreeSize); //larger child 
			if (comparator(*compareToMe,*large))
			{//getting the larger node
				compareToMe = large;
			}
		}

		vIterator previousHeap = iterator - LNumbers[sizeOfLastHeap];	//iterator to previous Heap
		
		if (comparator(*compareToMe, *previousHeap))
		{	//comparing size with previous heap
			iter_swap(iterator, previousHeap);	//swaps iterators for current and previous heap
			iterator = previousHeap;
			do {
				Lheap.tree_vector = Lheap.tree_vector >> 1;
				++Lheap.rightMostTreeSize;
			} while (!Lheap.tree_vector[0]);
		}
		else 
		{
			break;
		}		
	}
	FilterHeap(iterator, sizeOfLastHeap);	//Filtering the heaps
}


//Building the Heap
void LeonardoHeap::InsertIntoHeap(vIterator beginPtr, vIterator endPtr,vIterator heapEndPtr, LeonardoHeap& Lheap)
{	
	if (!Lheap.tree_vector[0])
	{//if no trees present, adding L(1) tree
		Lheap.tree_vector[0] = true;
		Lheap.rightMostTreeSize = 1;
	}
	else if (Lheap.tree_vector[1] && Lheap.tree_vector[0])
	{// if two smallest trees present, adding L(k+2) tree
		Lheap.tree_vector = Lheap.tree_vector >> 2;
		Lheap.tree_vector[0] = true;
		Lheap.rightMostTreeSize += 2;
	}

	else if (Lheap.rightMostTreeSize == 1)
	{//Adding L(0) tree
		Lheap.tree_vector = Lheap.tree_vector << 1;
		Lheap.rightMostTreeSize = 0;
		Lheap.tree_vector[0] = true;
	}
	else
	{//updating tree order
		Lheap.tree_vector <<= Lheap.rightMostTreeSize - 1;
		Lheap.tree_vector[0] = true;
		Lheap.rightMostTreeSize = 1;
	}

	bool LastOne = false;
	switch (Lheap.rightMostTreeSize)
	{
	case 0:
	{//if smallest tree is of size 0
		if (endPtr + 1 == heapEndPtr)
			LastOne = true;
		break;

	}		
	case 1:
	{//if smallest tree is of size 1
		if (endPtr + 1 == heapEndPtr || (endPtr + 2 == heapEndPtr && !Lheap.tree_vector[1]))
			LastOne = true;
		break;
	}
	default:
		if (size_t(distance(endPtr + 1, heapEndPtr)) < LNumbers[Lheap.rightMostTreeSize - 1] + 1)
			LastOne = true;
		break;
	}
	if (!LastOne)
		FilterHeap(endPtr, Lheap.rightMostTreeSize);
	else
		MaxHeapify(beginPtr, endPtr + 1, Lheap);
}

//DeQuiuing from the Heap
void LeonardoHeap::DeQ(vIterator beginPtr, vIterator endPtr,LeonardoHeap& Lheap)
{
	if (Lheap.rightMostTreeSize <= 1)
	{	//if the smallest tree size is less than 1 (L(0) or L(1) Tree)
		do
		{ //Do not heapify
			Lheap.tree_vector >>= 1;	//deq right most tree
			++Lheap.rightMostTreeSize;
		} while (Lheap.tree_vector.any() && !Lheap.tree_vector[0]);
		return;
	}

	//Tree Order Updation 
	const size_t hOrder = Lheap.rightMostTreeSize;	//heap order
	Lheap.tree_vector[0] = false;
	Lheap.tree_vector = Lheap.tree_vector << 2;	//updating order
	Lheap.tree_vector[1] = true;
	Lheap.tree_vector[0] = true;
	Lheap.rightMostTreeSize -= 2;

	//splitting the heaps 
	vIterator lHeap = LeftChild(endPtr - 1, hOrder);	//left heap
	vIterator rHeap = RightChild(endPtr - 1);	//right heap
	LeonardoHeap notLast= Lheap;	
	++notLast.rightMostTreeSize;
	notLast.tree_vector >>= 1;

	MaxHeapify(beginPtr, lHeap + 1, notLast);
	MaxHeapify(beginPtr, rHeap + 1, Lheap);
}


//Function that displays every 20th element in the list
void LeonardoHeap::shortenedListing()
{
	int k = 19;
	cout << "[";
	for (size_t i = 0; i < ElementsToSort.size(); i++)
	{
		k++;
		if (k == 20)
		{
			std::cout << ElementsToSort.at(i) << " ";
			k = 0;
		}
	}
	cout << "]";
}

//Function that swaps two nodes
void LeonardoHeap::swap(int e1, int e2)
{
	int temp;
	temp = ElementsToSort.at(e1);
	ElementsToSort.at(e1) = ElementsToSort.at(e2);
	ElementsToSort.at(e2) = temp;
}

//Function that computes permutations
void LeonardoHeap::permute(int e1, int e2, int e3)
{
	int r = rand() % 3 + 1; //generating random elements from 1-3
	switch (r)
	{
	case 1:
		swap(e1, e2);	//Permutation number 1, swapping e1 and e2
		break;
	case 2:
		swap(e2, e3);	//Permutation number 2, swapping e2 and e3
		break;
	case 3:
		swap(e1, e3);	//Permutation number 3, swapping e1 and e3
		break;
	}
}

//function that returns distinct random numbers everytime
int LeonardoHeap::DistinctRandomNumbers(int range)
{
	int flag = true;
	int element=0;
	while (flag)
	{
		flag = false;
		element = rand() % range + 1;		
		for (int i = 0; i < randomNumbers.size(); i++)
		{
			if (element == randomNumbers.at(i))
			{
				flag = true;
				break;
			}
		}		
	}
	
	return element;
}



