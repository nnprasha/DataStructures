#include "PriorityQueue.h"

// Function that displays the Priority Queue Items
void PriorityQueue::MinHeapDisplay()
{
	cout << "\n5.3) ----------- PriorityQueue DATA ITEMS DISPLAY: ----------\n";
	cout << "<<< ";
	if (MinHeap.size() < 1)
	{
		cout << "---HEAP EMPTY---";
	}
	for (int i = 0; i < MinHeap.size(); i++)
	{
		cout << "[" << MinHeap.at(i).at(0) << " " << MinHeap.at(i).at(1) << "]";
		cout << " ";
	}
	cout << " >>>";
	cout <<"\n\n";
}
//function that returns the index of the Parent
int PriorityQueue::Parent(int i)
{
	if (i % 2 == 0)	//if index is even
		return (i / 2) - 1;
	else 
		return (i / 2);	//If index is odd
}
//Function that returns the index of the Left Child
int PriorityQueue::Left(int i)
{
	return (2 * i) + 1;
}

//Function that returns the index of the Right Child
int PriorityQueue::Right(int i)
{
	return (2 * i) + 2;
}

//Function that swaps 2 nodes
void PriorityQueue::swap(int index1, int index2)
{
	vector<int> temp;
	temp = MinHeap.at(index2);
	MinHeap.at(index2) = MinHeap.at(index1);
	MinHeap.at(index1) = temp;
}

//Function that inserts a key into the PQ
void PriorityQueue::MinHeapInsert(vector<int> keyValue)
{
	MinHeap.push_back(keyValue);
	int index = MinHeap.size()-1;

	//------------Start of Block A---------------
	//Fixing the heap property after a new node has been inserted
	while (index > 0 && MinHeap.at(Parent(index)).at(0) > MinHeap.at(index).at(0))
	{	
		swap(index,Parent(index));
		index = Parent(index);
	}
	//------------Start of Block A---------------
}

//Function that extracts all the Minimum key values from the Heap
void PriorityQueue::HeapExtractAllMin(int index)
{
	if (MinHeap.size()<1)
	{
		cout << "---HEAP UNDERFLOW---";
		return;
	}
	vector<int> min = MinHeap.at(index);	//Min Node Present at index
	cout <<"[" << min.at(0) << " " << min.at(1) << "]"<<" ";
	MinHeap.at(index) = MinHeap.at(MinHeap.size() - 1);	//Min Node Extracted and replaced with last node
	MinHeap.pop_back();	//Size Decreased
	MinHeapify(0);	//Heapify Applied to maintain the Heap Property
	//-------Start of Block B------
	if (MinHeap.size() >= 1)
	{	//If the Heap size is greater than 1 after heapifying, and if the new root value is equal to old root value
		//then, HeapExtractAllMin is applied again
		if (min.at(0) == MinHeap.at(0).at(0))
			HeapExtractAllMin(0);
	}
	//-------End of Block B-------
}

//Function that transforms a distorted heap into a perfect heap(Heapify)
void PriorityQueue::MinHeapify(int index)
{
	if (MinHeap.size() < 1)
	{
		cout << "---HEAP UNDERFLOW!!---";
		return;
	}
	int left = Left(index);	//Left Child
	int right = Right(index);	//Right Child
	int smallest = 0;
	//Checking whether left child is smaller that root
	if (left < MinHeap.size() && MinHeap.at(left).at(0) <= MinHeap.at(index).at(0))
		smallest = left;
	else
		smallest = index;
	//Checking if right child is smaller than root or left child(whichever is smallest)
	if (right < MinHeap.size() && MinHeap.at(right).at(0) <= MinHeap.at(smallest).at(0))
		smallest = right;

	//Swapping root with smallest node and again Heapifying
	if (smallest != index)
	{
		swap(index, smallest);
		MinHeapify(smallest);
	}
}

//Function that displays all node values with minimum key
void PriorityQueue::AllMin(int index)
{
	if (MinHeap.size() < 1)
	{
		cout << " ---HEAP UNDERFLOW---";
		return;
	}
	cout << "[" << MinHeap.at(index).at(0) << " " << MinHeap.at(index).at(1) << "]"<<" ";	//Displaying minimum node
	int left = Left(index); //left child
	if (left < MinHeap.size() - 1)
	{
		if (MinHeap.at(left).at(0) == MinHeap.at(index).at(0))//If left child node value is equal to root node value
			AllMin(Left(index));	//then All Min called again
	}
	int right = Right(index);
	if (right < MinHeap.size() - 1)
	{
		if (MinHeap.at(right).at(0) == MinHeap.at(index).at(0))//If right Child Node value is equal to root node value
			AllMin(Right(index));	//then AllMin called again
	}
}

//Decreases the Value of key
void PriorityQueue::HeapDecreaseKey(int index, int newKey)
{
	if (MinHeap.size() < 1)
	{
		cout << "---HEAP UNDERFLOW!!---";
		return;
	}
	if (newKey > MinHeap.at(index).at(0))
	{	//if new key value is greater than old key value
		cout << "\n New key value Greater than old key Value";
		return;
	}
	cout << "Decreasing key value of data item [" << MinHeap.at(index).at(0)
		<< " " << MinHeap.at(index).at(1) << "]" << " to "<<newKey<<"-----> ";
	MinHeap.at(index).at(0) = newKey;	//setting the new key value
	cout <<"["<< MinHeap.at(index).at(0) << " " << MinHeap.at(index).at(1)<<"]";

	//------------------Start of Block C-------------------
	//Maintaining the Heap Property
	while (index > 0 && MinHeap.at(Parent(index)).at(0) > MinHeap.at(index).at(0))
	{
		swap(index, Parent(index));
		index = Parent(index);
	}
	//------------------End of Block C---------------------
}
