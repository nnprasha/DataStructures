======================================================================================================
								README.TXT
======================================================================================================
2 programs. 
1) Implement Priority Queue Operations (Extract-Min, Heapify etc)
2) Implement Smooth Sort Operations
-----------------------------------------------------------------------------------------------------
To Implement all the operations specified in the assignment, I have used 3 .cpp files and 2 .h files
-> main.cpp
	This file includes the main function of the program. In the main function, I have defined the 10 different test cases to execute. 
	The first 5 test cases are for the Priority Queue Operations, and the last 5 are for SmoothSort. 
	
	All the input is provided inside the main function. 	
	rand() is used to generate random numbers for input. srand() is also used so that new set of random nubers are generated each time the program executes.
	Header files used - 
		<iostream> - for cout/cin i.e input/output
		PriorityQueue.h , SmoothSort.h
		time.h- for srand()
				-------------------------------------------------------------------------------------------------------				
->PQ.cpp
	This is an implementation file that defines all the functions of the PriorityQueue class. 
	void PriorityQueue::MinHeapDisplay()-> Function that displays the Items of the Priority Queue
	//
	int PriorityQueue::Parent(int i)-> Returns the index to the parent of the current node. 
	//
	int PriorityQueue::Left(int i)-> Returns the Index to the left child of the current Node. 
	//
	int PriorityQueue::Right(int i)-> Returns the Index to the right child of the current Node. 
	//
	void PriorityQueue::swap(int index1, int index2)-> Swaps the 2 nodes. 
	//
	void PriorityQueue::MinHeapInsert(vector<int> keyValue)-> Inserts a new node into the Min Heap
		Block A Code- The new node is inserted in the last position in the Heap, so to maintain the minheap property, the nodes above the newly 
		inserted nodes are checked and swapped. 
	//
	void PriorityQueue::HeapExtractAllMin(int index)-> Function that returns all the deletes all the min key nodes from the Heap. 
		Block B code- After the root node is extracted and heapified, the root node value is checked again, if it is same as the previous root node
		value, HeapExtractAllMin is again called. 
	//
	void PriorityQueue::MinHeapify(int index)->Performs the Heapify operation on the Min Heap
	//
	void PriorityQueue::AllMin(int index)->Returns all the Minimum key nodes from the Heap, but it doenst get deleted from the Heap.
	//
	void PriorityQueue::HeapDecreaseKey(int index, int newKey)-> Decreases the key value of a node. 
		Block C Code- The key has been decreased and thus the heap property has to be maintained. so further swapping takes place with the Parent. 
				--------------------------------------------------------------------------------------------------------------
->SmoothSort.cpp
	This is an implementation file that defines all the functions of the LeonardoHeap Class. 
	LeonardoHeap::LeonardoHeap()->Constructor that initializes the LeonardoHeap and initializes the comparisions counter to 0. 
	//
	bool LeonardoHeap::comparator(int& element1,int& element2)-> Compares two values and returns true if 2nd value is bigger
	//
	vIterator LeonardoHeap::RightChild(vIterator rootElement)-> Returns the Right Child element. 
	//
	vIterator LeonardoHeap::LeftChild(vIterator rootElement, size_t sizeOfElement)-> Returns the Left Child Element
	//
	vIterator LeonardoHeap::LargerChild(vIterator rootElement, size_t sizeOfElement)-> Returns the Larger Child
	//
	void LeonardoHeap::FilterHeap(vIterator rootElement, size_t sizeOfElement)-> Filters all the Heaps and maintains the Leonardo heap Property of 
		having the larger root towards the right. 
	//
	void LeonardoHeap::MaxHeapify(vIterator beginPtr, vIterator endPtr, LeonardoHeap Lheap)-> Heapifies the heap to maintain the heap property. 
	//
	void LeonardoHeap::InsertIntoHeap(vIterator beginPtr, vIterator endPtr,vIterator heapEndPtr, LeonardoHeap& Lheap)-> Inserts the new 
		Element into the Leonardo Heap. 
	//
	void LeonardoHeap::DeQ(vIterator beginPtr, vIterator endPtr,LeonardoHeap& Lheap)-> Dequeues the largest element from the Leonardo Heap. 
	//
	void Init(vIterator,vIterator,LeonardoHeap);->Starting point of SmoothSort. Called from the main function. 
	//
	void LeonardoHeap::shortenedListing()-> displays every 20th element.
	//
	void LeonardoHeap::swap(int e1, int e2)-> Swaps the 2 elements. 
	//
	void LeonardoHeap::permute(int e1, int e2, int e3)-> Performs permutations on the input vector. Uses a randomly generated value to perform 
		the specified permutation. 
	------------------------------------------------------------------------------------------------------------
->PriorityQueue.h
	Defines the PriorityQueue Class. 
			------------------------------------------------------------------------------------------------------------
->SmoothSort.h
	Defines the LeonardoHeap Class.
	Also defines a vector iterator that iterates over the input vector and an array that stores Leonardo Numbers. These Leonardo numbers are required
	to check for the size of the tree when the order is given. 
			------------------------------------------------------------------------------------------------------------

	=======================================================================================================================================================
	