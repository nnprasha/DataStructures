#ifndef SMOOTHSORT_H
#define SMOOTHSORT_H

#include <iostream>
#include <stdio.h>
#include <iterator>
#include <bitset>
#include <vector>
#include <cstdlib>

using namespace std;

//Iterator for the input vector of Elements
typedef vector<int>::iterator vIterator;

//Array of Leonardo Numbers, used for getting the order of trees
const size_t LNumbers_count = 19;
const size_t LNumbers[LNumbers_count] = { 1, 1, 3, 5, 9, 15, 25, 41, 67, 109, 177, 287,
												465, 753,1219, 1973, 3193, 5167, 8361 };

//Class that creates leonardo heaps and sorts the elements using SmoothSort
class LeonardoHeap
{
public:
	vector<int> ElementsToSort; //Input Vector of elements
	vector<int> randomNumbers;	//Vector for distinct random numbers

	bitset<LNumbers_count> tree_vector;	//Bit vector for the heap
	size_t rightMostTreeSize;	//Smallest tree size	
	int comparisonsCounter;	//Counter for the number of comparisions

	LeonardoHeap();
	void Init(vIterator,vIterator,LeonardoHeap); //Starting point for smooth sort	
	vIterator RightChild(vIterator);	//Returns the right child of a node 
	vIterator LeftChild(vIterator, size_t);	//Returns the Left Child of a Node
	vIterator LargerChild(vIterator, size_t);	//Returns the Larger Child of a Node
	void FilterHeap(vIterator, size_t);	//Filters the Heaps and maintains the Leonardo heap properties
	void MaxHeapify(vIterator, vIterator,LeonardoHeap);	//Maintains individual Heap Properties
	void InsertIntoHeap(vIterator, vIterator, vIterator,LeonardoHeap&);	//Inserts element into Heap
	void DeQ(vIterator, vIterator, LeonardoHeap&);	//Dequeues the largest element from the Heap
	bool comparator(int&, int&);	//Comparator that compares value of 2 nodes
	void shortenedListing();	//displays every 20th element
	void swap(int, int);	//Swaps two elements
	void permute(int, int, int);	//Performs Permutations on 3 elements
	int DistinctRandomNumbers(int);
};


#endif 
