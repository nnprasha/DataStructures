#ifndef PRIORITYQUEUE_H
#define PRIORITYQUEUE_H
//The above statements act as a guard to avoid including this header file again and again
#include <vector>
#include <iostream>
#include <cstdlib>
using namespace std;

class PriorityQueue{
	public:
		vector< vector<int> > MinHeap;	//Input Vector that defines the Priority Queue
		void MinHeapDisplay();	//Displays the Priority Queue Vector
		void HeapExtractAllMin(int);	//Functionn to Extract all minimum value keys from the Heap
		void AllMin(int);	//Function that displays all the Minimum keys from the Heap
		void HeapDecreaseKey(int,int);	//Function that decreases the key value to a new key
		void MinHeapInsert(vector<int>);	//Function that inserts a node([key value]) to the Heap
		void MinHeapify(int);	//Function to Heapify i.e to maintain the Min Heap Property
		void swap(int, int);	//Function that swaps the two nodes
		int Parent(int);	//Returns the Parent node
		int Left(int);	//Returns the Left Child
		int Right(int);	//Returns the Right child
};


#endif 
