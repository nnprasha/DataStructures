// ADS-Assignment2.cpp : Defines the entry point for the console application.
//

#include <time.h>
#include "PriorityQueue.h"
#include "SmoothSort.h"
#include <iostream>
using namespace std;

int main()
{
	
	PriorityQueue PQ;
	srand(time(NULL));

	//-----------------------------TEST CASE #1-----------------------------------
	cout << "=============================================================\n";
	cout << "\t\tTEST CASE #1\n";
	cout << "=============================================================\n";
	cout << "1.1) ----Inserting nodes [100 1] [99 2] ... [1 100]----\n";
	cout << "Inserted!!\n";
	int value = 1;
	for (int i = 100; i > 0; i--)
	{
		
		vector<int> keyValue;
		keyValue.push_back(i);
		keyValue.push_back(value);
		PQ.MinHeapInsert(keyValue);
		value++;
		//cout << "[" << keyValue.at(0) << " " << keyValue.at(1) << "]" << " ";
	}
	cout << "\n\n1.2) ---Applying Extract-ALL Min Operations:----\n";
	cout << "Extracted Min Node: ";
	PQ.HeapExtractAllMin(0);

	cout << "\n\n1.3) ----Inserting data [1 0] to the PQ----\n";
	cout << "Inserted!!\n";
	vector<int> keyValue;
	keyValue.push_back(1);
	keyValue.push_back(0);
	PQ.MinHeapInsert(keyValue);
	
	cout << "\n\n1.4) ---Applying Extract-ALL Min Operations:----\n";
	cout << "Extracted Min Node: ";
	PQ.HeapExtractAllMin(0);

	PQ.MinHeap.clear();	//Deleting the Heap

	//---------------------------TEST CASE #2-------------------------------------
	
	cout << "\n\n=============================================================\n";
	cout << "\t\tTEST CASE #2\n";
	cout << "=============================================================\n";
	cout << "2.1) ----Inserting nodes [1000 1] [999 2] ... [1 1000]----\n";
	cout << "Inserted!!\n";
	value = 1;
	for (int i = 1000; i > 0; i--)
	{
		vector<int> keyValue;
		keyValue.push_back(i);
		keyValue.push_back(value);
		PQ.MinHeapInsert(keyValue);
		value++;
	}

	cout << "\n2.2) -------Applying ALLMin Operation---------\n";
	cout << "All-Min: ";
	PQ.AllMin(0);

	cout << "\n\n2.3) ----Inserting nodes [1 1] [1 2] ... [1 30]----\n";
	cout << "Inserted!!\n";
	for (int i = 1; i <= 30; i++)
	{
		vector<int> keyValue;
		keyValue.push_back(1);
		keyValue.push_back(i);
		PQ.MinHeapInsert(keyValue);		
	}
		
	cout << "\n\n2.4) ---------Applying Extract All Min------------\n";
	cout << "Extracted Min Node: ";
	PQ.HeapExtractAllMin(0);
	
	cout << "\n\n2.5) -------Applying ALLMin Operation---------\n";
	cout << "All-Min: ";
	PQ.AllMin(0);
	
	PQ.MinHeap.clear();

	//---------------------------TEST CASE #3-------------------------------------

	cout << "\n\n=============================================================\n";
	cout << "\t\tTEST CASE #3\n";
	cout << "=============================================================\n";

	cout << "3.1) -----Inserting 500 randomly generated data items to PQ------\n";
	
	cout << "Values Inserted: ";
	for (int i = 0; i < 500; i++)
	{
		vector<int> keyValue;
		keyValue.push_back(rand() % 1000 + 10);
		keyValue.push_back(rand() % 1000 + 10);
		cout << "[" << keyValue.at(0) << " " << keyValue.at(1) << "] ";
		PQ.MinHeapInsert(keyValue);
	}
	
	cout << "\n\n3.2) -----Applying Extract-All-Min Operation to PQ 5 times------\n";
	for (int i = 0; i < 5; i++)
	{
		cout << "\nExract All-Min Nodes (#" << i+1 << "): ";
		PQ.HeapExtractAllMin(0);
	}

	cout << "\n\n3.3) ------Decreasing key value to 5 of a randomly selected data item------\n";
	int randomItem = rand() % PQ.MinHeap.size();	
	PQ.HeapDecreaseKey(randomItem, 5);

	cout << "\n\n3.4) -------Applying ALL-Min Operation to PQ-------";
	cout << "\nMin Values: ";
	PQ.AllMin(0);
	
	PQ.MinHeap.clear();

	//---------------------------TEST CASE #4-------------------------------------

	cout << "\n\n=============================================================\n";
	cout << "\t\tTEST CASE #4\n";
	cout << "=============================================================\n";

	cout << "\n4.1) -----Inserting 500 randomly generated data items to PQ------\n\n";

	cout << "Values Inserted: ";
	for (int i = 0; i < 500; i++)
	{
		vector<int> keyValue;
		keyValue.push_back(rand() % 1000 + 10);
		keyValue.push_back(rand() % 1000 + 10);
		cout << "[" << keyValue.at(0) << " " << keyValue.at(1) << "] ";
		PQ.MinHeapInsert(keyValue);
	}

	cout << "\n\n4.2) ------Performing Decreasing key Operation 10 times------\n";
	for (int i = 0; i < 10; i++)
	{
		int randomItem = rand() % PQ.MinHeap.size();
		PQ.HeapDecreaseKey(randomItem, rand()%10);
		cout << endl;
	}
	
	cout << "\n\n4.3) -------Applying Extract-All-Min operation 10 times-------\n";
	for (int i = 0; i < 10; i++)
	{
		cout << "\nExtract All-Min Nodes (#" << i + 1 << "): ";
		PQ.HeapExtractAllMin(0);
	}

	PQ.MinHeap.clear();
	//---------------------------TEST CASE #5-------------------------------------

	cout << "\n\n=============================================================\n";
	cout << "\t\tTEST CASE #5\n";
	cout << "=============================================================\n";

	cout << "\n5.1) -----100 randomly generated operations-----\n\n";
	int displayCount = 0;
	for (int i = 0; i < 100; i++)
	{
		displayCount++;
		int rOperation = rand() % 4 + 1; //random number between 1 to 4
		cout <<"  "<< i + 1 << ".";

		switch (rOperation)
		{
			case 1:
			{
				cout << "Insertion Operation.";
				vector<int> keyValue;
				keyValue.push_back(rand() % 1000);
				keyValue.push_back(rand() % 1000);
				cout << " ([" << keyValue.at(0) << " " << keyValue.at(1) << "])";
				cout << endl;
				PQ.MinHeapInsert(keyValue);
				break;
			}
			case 2:
			{
				cout << "All-minimum Operation. ";
				cout << "(";
				PQ.AllMin(0);
				cout << ")";
				cout << endl;				
				break;
			}
			case 3:
			{
				cout << "Extract All-Min Operation.";
				cout << "(";
				PQ.HeapExtractAllMin(0);
				cout << ")";
				cout<<endl;
				break;
			}
			case 4:
			{
				cout << "Decrease Key Operation.";
				if (PQ.MinHeap.size() >= 1)
				{
					int randomItem = rand() % PQ.MinHeap.size();
					int x = PQ.MinHeap.at(0).at(0);
					int rKey;
					if (x == 0)
						rKey = 0;	//if root key is 0, we set the new key to 0 as well
					else
					    rKey = rand()%PQ.MinHeap.at(0).at(0); //random key that is less than the root key
					cout << "(Root Key(Smallest of all existing keys):" << PQ.MinHeap.at(0).at(0) << " NewKey: " << rKey << " || ";
					PQ.HeapDecreaseKey(randomItem, rKey);
					cout << ")";
				}
				else
				{
					cout << "(---HEAP UNDERFLOW---)";
				}
				cout << endl;
				break;
			}				
			default:
				break;
		}

		if (displayCount == 20)
		{
			PQ.MinHeapDisplay();
			displayCount = 0;
		}
	}
	PQ.MinHeap.clear();

	//-------------------------------------------------------------------------------------------------------
	
	
	//---------------------------TEST CASE #6-------------------------------------
	cout << "\n\n=============================================================\n";
	cout << "\t\tTEST CASE #6\n";
	cout << "=============================================================\n";
	LeonardoHeap lh;
	for (int i = 1000; i > 0; i--)
	{
		lh.ElementsToSort.push_back(i);
	}
	cout << "\n6.1) ------Data set to [1000,999,998,...,1]-------\n";

	lh.Init(lh.ElementsToSort.begin(),lh.ElementsToSort.end(),lh);

	cout << "\n6.2) ------Smooth Sort Applied-------\n";

	cout << "\n6.3) ------No. Of Comparisons-------\n";
	cout << "The total number of comparisons among elements in A performed = " << lh.comparisonsCounter;
	cout << endl;

	cout << "\n6.4) ------Shortened listing-------\n";
	cout << "A shortened listing of element of A: ";
	lh.shortenedListing();
	
	lh.ElementsToSort.clear();
	lh.comparisonsCounter = 0;
	cout << endl;

	//---------------------------TEST CASE #7-------------------------------------
	cout << "\n\n=============================================================\n";
	cout << "\t\tTEST CASE #7\n";
	cout << "=============================================================\n";
	
	for (int i = 1; i <= 2000; i++)
	{
		lh.ElementsToSort.push_back(i);
	}

	cout << "\n7.1) ------Data set to [1,2,3,...,2000]-------\n";

	cout << "\n7.2) ------Selecting 20 Randomly generated numbers from 1-2000-------\n";
	lh.randomNumbers.clear();
	for (int i = 0; i < 10; i++)
	{
		int i1 = lh.DistinctRandomNumbers(2000);
		lh.randomNumbers.push_back(i1);
		int i2 = lh.DistinctRandomNumbers(2000);
		lh.randomNumbers.push_back(i2);
		cout << "Selecting: ";
		cout << "i" << i * 2 + 1 << "=" << i1 << " & " ;
		cout << "i" << (i + 1) * 2 << "=" << i2 << endl;
		cout << " Swapping A[" << i1 << "]" << " and A[" << i2 << "]";
		cout << endl;
		lh.swap(i1, i2);
	}

	cout << "\n7.3) ------Smooth Sort Applied-------\n";
	lh.Init(lh.ElementsToSort.begin(),lh.ElementsToSort.end(),lh);

	cout << "\n7.4) ------No. Of Comparisons-------\n";
	cout << "The total number of comparisons among elements in A performed = " << lh.comparisonsCounter;
	cout << endl;

	cout << "\n7.5) ------Shortened listing-------\n";
	cout << "A shortened listing of element of A: ";
	lh.shortenedListing();

	lh.ElementsToSort.clear();
	lh.comparisonsCounter = 0;

	//---------------------------TEST CASE #8-------------------------------------
	cout << "\n\n=============================================================\n";
	cout << "\t\tTEST CASE #8\n";
	cout << "=============================================================\n";

	for (int i = 1; i <= 2000; i++)
	{
		lh.ElementsToSort.push_back(i);
	}

	cout << "\n8.1) ------Data set to [1,2,3,...,2000]-------\n";

	cout << "\n8.2) ------Selecting 60 Randomly generated numbers between 1-1000-------\n";
	int p = 0;
	lh.randomNumbers.clear();
	while (p < 60)
	{
		int e1 = lh.DistinctRandomNumbers(1000);
		lh.randomNumbers.push_back(e1);
		int e2 = lh.DistinctRandomNumbers(1000);
		lh.randomNumbers.push_back(e2);
		int e3 = lh.DistinctRandomNumbers(1000);
		lh.randomNumbers.push_back(e3);
		cout << "Selecting i" << p + 1 << ": " << e1;
		cout << " i" << p + 2 << ": " << e2;
		cout << " i" << p + 3 << ": " << e3;
		cout << "\n Permuting A[" <<e1<< "] A["<<e2<< "] A["<<e3<< "]";
		lh.permute(e1, e2, e3);
		p = p + 3;
		cout << endl;
	}
	
	cout << "\n8.3) ------Smooth Sort Applied-------\n";
	lh.Init(lh.ElementsToSort.begin(), lh.ElementsToSort.end(), lh);
	
	cout << "\n8.4) ------No. Of Comparisons-------\n";
	cout << "The total number of comparisons among elements in A performed = " << lh.comparisonsCounter;
	cout << endl;

	cout << "\n8.5) ------Shortened listing-------\n";
	cout << "A shortened listing of element of A: ";
	lh.shortenedListing();

	lh.ElementsToSort.clear();
	lh.comparisonsCounter = 0;
	//---------------------------TEST CASE #9-------------------------------------
	cout << "\n\n=============================================================\n";
	cout << "\t\tTEST CASE #9\n";
	cout << "=============================================================\n";

	
	cout << "\n9.1) ---------------Vector set to a length 3193------------\n ";
	lh.ElementsToSort.resize(LNumbers[16]);	//LNumbers[16] contains 3193
	
	cout << "\n9.2) ---------------Randomly selecting numbers between 1 - 10000--------------\n";
	for (size_t i = 0; i < lh.ElementsToSort.size(); i++)
	{
		lh.ElementsToSort.at(i) = rand() % 10000 + 1;
	}
	
	cout << "\n9.3) ------------Applying SmoothSort to the Input Vector------------\n";
	lh.Init(lh.ElementsToSort.begin(), lh.ElementsToSort.end(), lh);

	cout << "\n9.4) ------No. Of Comparisons-------\n";
	cout << "The total number of comparisons among elements in A performed = " << lh.comparisonsCounter;
	cout << endl;

	cout << "\n9.5) ------Shortened listing-------\n";
	cout << "A shortened listing of element of A: ";
	lh.shortenedListing();

	lh.ElementsToSort.clear();
	lh.comparisonsCounter = 0;
	//---------------------------TEST CASE #10-------------------------------------
	cout << "\n\n=============================================================\n";
	cout << "\t\tTEST CASE #10\n";
	cout << "=============================================================\n";


	cout << "\n10.1) ---------------Vector set to a length 5166(sum of 3193 and 1973------------\n ";
	lh.ElementsToSort.resize(LNumbers[16]+LNumbers[15]);//LNumbers[16] and LNumbers[15] contains 3193 and 1973 respectively

	cout << "\n10.2) ---------------Randomly selecting numbers between 1 - 10000--------------\n";
	for (size_t i = 0; i < lh.ElementsToSort.size(); i++)
	{
		lh.ElementsToSort.at(i) = rand() % 10000 + 1;
	}

	cout << "\n10.3) ------------Applying SmoothSort to the Input Vector------------\n";
	lh.Init(lh.ElementsToSort.begin(), lh.ElementsToSort.end(), lh);

	cout << "\n10.4) ------No. Of Comparisons-------\n";
	cout << "The total number of comparisons among elements in A performed = " << lh.comparisonsCounter;
	cout << endl;

	cout << "\n10.5) ------Shortened listing-------\n";
	cout << "A shortened listing of element of A: ";
	lh.shortenedListing();
	cout << endl;
    return 0;
	
}

