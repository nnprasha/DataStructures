
#include "KDTree.h"
#include <sstream>
#include <stdio.h>
using namespace std;

//Constructor for KDNode
KDNode::KDNode() {
	x = 0;
	y = 0;
	value = 0;
	left = NULL;
	right = NULL;
	parent = NULL;
}

//Constructor for KD tree
KDTree::KDTree() {
	root = NULL;
	k = 2; //2d Tree
}

//function that inserts a node into the KDTree
void KDTree::Insert(KDNode* node) {
	int i = 0;
	KDNode* p = root;
	KDNode* prev = NULL;
	while (p != NULL)
	{
		prev = p;
		if (node->multiKeys.at(i) <= p->multiKeys.at(i))
			p = p->left; //Insertion in the left subtree
		else
			p = p->right; //Insertion in the right subtree
		i = (i + 1) % k;
	}
	if (root == NULL)
	{ //if root is NUll, we make the new node as root
		root = node;
		node->parent = NULL;
	}		
	else if (node->multiKeys.at((i + 1) % k) <= prev->multiKeys.at((i + 1) % k))
	{ //if key is <= parent, we add it to the left subtree
		prev->left = node;
		node->parent = prev;
	}
	else
	{ //adding to the right subtree
		prev->right = node;
		node->parent = prev;
	}
		
}

//Inorder Display 
void KDTree::InorderDisplay(KDNode* root)
{
	if (root != NULL)
	{
		InorderDisplay(root->left);
		cout << "[" << root->x << "," << root->y <<","<<root->value <<"] ";
		InorderDisplay(root->right);
	}
}

//Preorder Display
void KDTree::PreorderDisplay(KDNode* root)
{
	if (root != NULL)
	{
		cout << "[" << root->x << "," << root->y << "," <<root->value << "] ";
		PreorderDisplay(root->left);
		PreorderDisplay(root->right);
	}
}

//Function that returns the height of the KDTree
int KDTree::Height(KDNode* currRoot)
{
	if (currRoot == NULL)
		return -1; //-1 if root is null
	else
	{
		int hLeft = Height(currRoot->left); //height of left subtree
		int hRight = Height(currRoot->right); //height of right subtree

		if (hLeft > hRight)
			return hLeft + 1; //returns height of left subtree + 1 if height of left subtree is greater
		else
			return hRight + 1; //else returns height of right subtree + 1
	}
}

//Function that returns Distinct keys for a given range
vector<int> KDTree::DistinctKeys(int range)
{
	int flag = true;
	int keyX = 0;
	int keyY = 0;
	while (flag)
	{
		flag = false;
		keyX = rand() % range;
		keyY = rand() % range;
		for (int i = 0; i < distinctKeys.size(); i++)
		{
			if (keyX == distinctKeys.at(i).at(0) && keyY == distinctKeys.at(i).at(1))
			{
				flag = true;
				break;
			}
		}
	}
	vector<int> keysXY;
	keysXY.push_back(keyX);
	keysXY.push_back(keyY);
	distinctKeys.push_back(keysXY);
	return keysXY;
}

//Function that deletes a node from the KDTree
void KDTree::DeleteNode(KDNode* node, int i)
{
	if (node == NULL) //if node is NULL
		return;

	KDNode* q = NULL;
	
	if (node->left == NULL && node->right == NULL)
	{ 
		if (node->parent == NULL)
		{ //if node is the ROOT
			root = NULL;
			return;
		}
		//node to be deleted is the Leaf Node
		if (node->parent != NULL)
		{
			if (node->parent->left == node)
				node->parent->left = NULL; 
			else
				node->parent->right = NULL;
		}
		
		delete node; 
		return;
	}
	else if (node->right != NULL) //if right subtree is not NULL
		q = Smallest(node->right, i, (i + 1) % k);
	else
	{ //if left subtree is not NULL
		q = Smallest(node->left, i, (i + 1) % k);
		node->right = node->left;
		node->left = NULL;
	}
	node->x = q->x; //Replacing the deleted node values , and then recursively will delete the other node found
	node->y = q->y;
	node->value = q->value;
	node->multiKeys.at(0) = q->multiKeys.at(0);
	node->multiKeys.at(1) = q->multiKeys.at(1);
	int d = Depth(q);
	i = d % k; //changing the node discriminator value 
	DeleteNode(q,i);
}

//function that returns depth of a given node
int KDTree::Depth(KDNode* q)
{
	int d = 0;
	KDNode* x = q;
	while (x->parent != NULL)
	{
		d++;
		x = x->parent;
	}
	return d;
}

//function that returns the node with smallest key for a given discriminator in a subtree
KDNode* KDTree::Smallest(KDNode* q, int i, int j)
{
	KDNode* qq = q;
	KDNode* lt = NULL;
	KDNode* rt = NULL;
	
	if (q->left != NULL)
	{//if left subtree is not null, search for smallest key in left subtree
		lt = Smallest(q->left, i, (j + 1) % k);
		if (qq->multiKeys.at(i) >= lt->multiKeys.at(i))
			qq = lt;
	}

	if (q->right != NULL)
	{ //if right subtree is not null, search for smallest key in right subtree
		rt = Smallest(q->right, i, (j + 1) % k);
		if (qq->multiKeys.at(i) >= rt->multiKeys.at(i))       
			qq = rt;
	}
	return qq;
}

//Utility Function to generate distinct random numbers
int KDTree::DistinctRandomNumbers(int range)
{
	int flag = true;
	int ele = 0;
	while (flag)
	{
		flag = false;
		ele = rand() % range;
		for (int i = 0; i < randomElements.size(); i++)
		{
			if (ele == randomElements.at(i))
			{
				flag = true;
				break;
			}
		}
	}
	randomElements.push_back(ele);
	return ele;
}

//function that compares two nodes
bool KDTree::ComparePoints(KDNode* currRoot, vector<int> keys)
{
	if (currRoot->x == keys.at(0) && currRoot->y == keys.at(1)
		&& currRoot->value == keys.at(2) && currRoot->multiKeys.at(0) == keys.at(0) && 
		currRoot->multiKeys.at(1) == keys.at(1))
		return true; //true if nodes are same
	return false; //else false
}

//function that seaches for node in a KDTree
bool KDTree::SearchNode(KDNode* node, vector<int> keys, int depth)
{
	if (node == NULL)
		return false; //false if node is NULL
	if (ComparePoints(node, keys))
		return true; //true if nodes are same
	
	int currentDimension = depth % k; //changes dimension for every level 

	if (keys.at(currentDimension) <= node->multiKeys.at(currentDimension))
		return SearchNode(node->left, keys, depth + 1);

	return SearchNode(node->right, keys, depth + 1);
}

//Prints a Null node, represented by a point, in the dot fule
void KDTree::PrintDotNull(string key, int nullcount, FILE* stream)
{
	fprintf(stream, "    null%d [shape=point];\n", nullcount);
	fprintf(stream, "    \"%s\" -> null%d;\n", key.c_str(), nullcount);
}

//Prints a node in the dot file
void KDTree::PrintDot(KDNode* node, FILE* stream)
{
	static int nullcount = 0;

	if (node->left != NULL)
	{
		ostringstream convert;
		convert << node->x << "," << node->y << "," << node->value;
		string k1 = convert.str(); //converts integers to strings in a dot file
		convert.str("");
		convert << node->left->x << "," <<node->left->y<<","<< node->left->value;
		string k2 = convert.str().c_str();
		fprintf(stream, "    \"%s\" -> \"%s\";\n", k1.c_str(), k2.c_str());
		PrintDot(node->left, stream);
	}
	else
	{
		ostringstream convert;
		convert << node->x << "," << node->y << "," << node->value;
		string k1 = convert.str();
		PrintDotNull(k1, nullcount++, stream);
	}

	if (node->right != NULL)
	{
		ostringstream convert;
		convert << node->x << "," <<node->y<<","<< node->value;
		string k1 = convert.str();
		convert.str("");
		convert << node->right->x << "," <<node->right->y<<","<< node->right->value;
		string k2 = convert.str();
		fprintf(stream, "    \"%s\" -> \"%s\";\n", k1.c_str(), k2.c_str());
		PrintDot(node->right, stream);
	}
	else
	{
		ostringstream convert;
		convert << node->x << "," << node->y<<","<<node->value;
		string k1 = convert.str();
		PrintDotNull(k1, nullcount++, stream);
	}


}

//function that creates a dot file 
void KDTree::showKD(KDNode* root, string fileName)
{
	FILE* stream = fopen(fileName.c_str(), "w");
	fprintf(stream, "digraph KD {\n");
	fprintf(stream, "    node [fontname=\"Arial\"];\n");
	if (root == NULL)
		fprintf(stream, "\n"); //if root is null
	else if (root->right == NULL && root->left == NULL)
	{	//node is a leaf node
		ostringstream convert;
		convert << root->x << "," << root->y<<","<<root->value;
		string k = convert.str();
		fprintf(stream, "    \"%s\";\n", k.c_str());
	}
	else
		PrintDot(root, stream);

	fprintf(stream, "}\n");
	fclose(stream);
}
