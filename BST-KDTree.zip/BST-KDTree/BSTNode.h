#ifndef BSTNODE_H
#define BSTNODE_H
//The above statements act as a guard to avoid including this header file again and again

#include <iostream>
#include <cstdlib>
using namespace std;
class BSTNode {
public:
	int value; //defines the value
	int key; //defines the key
	BSTNode* left; //left node
	BSTNode* right; //right node
	BSTNode* parent; //parent

	BSTNode(); //Constructor
};
#endif