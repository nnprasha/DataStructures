#ifndef KDTREE_H
#define KDTREE_H
//The above statements act as a guard to avoid including this header file again and again

#include "KDNode.h"
#include <iostream>
#include <cstdlib>
using namespace std;
class KDTree {
public:
	KDNode* root; //root node
	int k; //dimension, for this assignment k will always be 2
	vector<vector<int> > distinctKeys; 
	vector<int> randomElements;

	KDTree(); //Constructor
	void Insert(KDNode*); //Inserts a node to the KDTree
	void InorderDisplay(KDNode*); //Inorder Display
	void PreorderDisplay(KDNode*); //Preorder display
	int Height(KDNode*); //Height of the tree
	vector<int> DistinctKeys(int); //Returns distinct keys
	void DeleteNode(KDNode*,int); //Deletes a node from the tree
	bool SearchNode(KDNode*, vector<int>, int); //Searches for a node from the given tree
	bool ComparePoints(KDNode*, vector<int>); //Compares two nodes
	int Depth(KDNode*); //returns the depth of a node
	KDNode* Smallest(KDNode*, int, int); //returns the node with the smallest keys
	int DistinctRandomNumbers(int); //random nunmbers generator(Distinct)

	/*
	 Below functions create the dot file
	*/
	void showKD(KDNode*, string);
	void PrintDot(KDNode*, FILE*);
	void PrintDotNull(string, int, FILE*);
	
};





#endif
