﻿// ADS-Assignment3.cpp : Defines the entry point for the console application.
//


#include "BST.h"
#include "KDTree.h"
#include <iostream>
#include <vector>
#include <time.h>
#include <math.h>
#include <iomanip>
#include <cstdlib>
using namespace std;

int main()
{
	srand(time(NULL));

	//-----------------------------TEST CASE #1-----------------------------------
	cout << "=============================================================\n";
	cout << "\t\tTEST CASE #1\n";
	cout << "=============================================================\n";
	vector<int> keys;	//List to store all the keys of Test Case 1
	vector<vector<int> > list1;//List for Test Case 1	
	
	BST bst1;

	for (int i = 0; i <= 15; i++)
	{
		BSTNode* node = new BSTNode();
		if (i == 0)
		{ //for n=0
			node->key = 0;			
			node->value = 0;			
		}
		else if (i == 1)
		{ //for n=1
			node->key = 1000;			
			node->value = 1;		
		}
		else
		{	//for n>=2 	
			node->key = (keys.at(i - 2) + keys.at(i - 1)) / 2;			
			node->value = i;
		}
		keys.push_back(node->key);
		cout << "Inserting: [" << node->key << "," << node->value << "]";
		bst1.Insert(node);
		vector<int> kv;
		kv.push_back(node->key);
		kv.push_back(node->value);
		list1.push_back(kv);	//Inserting vector of [key,value] in List1 vector
		cout << endl;		
	}
	cout << endl;
	cout << "Inorder Display: ";
	bst1.InorderDisplay(bst1.root);	//Inorder Display;
	bst1.showBST(bst1.root, "t1.dot"); //Creating dot file t1.dot
	cout << endl << endl << "t1.dot file created!!";
	cout << endl;


	//-----------------------------TEST CASE #2-----------------------------------
	cout << "\n=============================================================\n";
	cout << "\t\tTEST CASE #2\n";
	cout << "=============================================================\n";
	KDTree kd1;
	vector<vector<int> > list2;	//List for Test Case 2
	vector<int> kd_XKeys;	//List to store x point keys

	for (int i = 0; i <= 15; i++)
	{
		KDNode* node = new KDNode();
		if (i == 0)
		{//for n=0
			node->x = 0;
		}
		else if (i == 1)
		{//for n=1
			node->x = 500;
		}
		else
		{//for n>=2
			node->x = (kd_XKeys.at(i - 2) + kd_XKeys.at(i - 1)) / 2;
		}
		node->y = 500 - (node->x);
		node->multiKeys.push_back(node->x); //storing 
		node->multiKeys.push_back(node->y); // x,y keys in vector
		node->value = i;
		kd_XKeys.push_back(node->x);
		kd1.Insert(node);
		cout << "Inserting: [" << node->x << "," << node->y <<","<<node->value<< "]";
		vector<int> keyXYValue;
		keyXYValue.push_back(node->x);
		keyXYValue.push_back(node->y);
		keyXYValue.push_back(node->value);
		list2.push_back(keyXYValue);	//Adding [x,y,value] as a vector to list 2
		cout << endl;
	}
	cout << endl;
	cout << "Inorder Display: ";
	kd1.InorderDisplay(kd1.root);
	cout << endl << endl;
	kd1.showKD(kd1.root,"t2.dot"); //Creating dot file t2.dot
	cout << "t2.dot file Created!!\n";

	//----------------------Test Case #3---------------------------------
	cout << "\n\n=============================================================\n";
	cout << "\t\tTEST CASE #3\n";
	cout << "=============================================================\n";
	
	BST bst3;

	int count = 0;
	int nodeCount = 0;
	cout << endl;
	cout << "=======================================================================================\n";
	cout << "\tn=No of Nodes|" << "\tHeight of BST T3|" << "\tlgn|" << "\t√n\n";
	cout << "=====================================================================================\n";

	for (int i = 0; i < 200; i++)
	{
		if (count % 20 == 0)
		{//for every 20th node
			if (bst3.root == NULL) //if root is null, lgn will be -NA-
				cout << setw(20) << nodeCount << setw(15) << bst3.Height(bst3.root) << setw(15) << "-NA-" << setw(15) << sqrt(count);
			else //if root is not null
				cout << setw(20) << nodeCount << setw(15) << bst3.Height(bst3.root) << setw(15) << log2(count) << setw(15) << sqrt(count);
			cout << endl;
			nodeCount += 20;
		}
		BSTNode* newNode = new BSTNode();
		newNode->key = bst3.DistinctKeys(1000); //node generation with distinct keys
		newNode->value = rand() % 1000 + 1;
		bst3.Insert(newNode);
		count++;
	}
	//for the 200th node
	cout << setw(20) << nodeCount << setw(15) << bst3.Height(bst3.root) << setw(15) << log2(count) << setw(15) << sqrt(count);
	cout << endl;

	//-----------------------------TEST CASE #4-----------------------------------
	cout << "\n\n=============================================================\n";
	cout << "\t\tTEST CASE #4\n";
	cout << "=============================================================\n";
	KDTree kd2;
	
	int countKD = 0;
	int nodeCountKD = 0;
	cout << endl;
	cout << "=======================================================================================\n";
	cout << "\tn=No of Nodes|" << "\tHeight of BST T4|" << "\tlgn|" << "\t√n\n";
	cout << "=====================================================================================\n";

	for (int i = 0; i < 200; i++)
	{
		if (countKD % 20 == 0)
		{
			if (kd2.root == NULL) //if root is null, lgn will be -NA-
				cout << setw(20) << nodeCountKD << setw(15) << kd2.Height(kd2.root) << setw(15) << "-NA-" << setw(15) << sqrt(countKD);
			else //if root is not null
				cout << setw(20) << nodeCountKD << setw(15) << kd2.Height(kd2.root) << setw(15) << log2(countKD) << setw(15) << sqrt(countKD);
			cout << endl;
			nodeCountKD += 20;
		}
		KDNode *node = new KDNode();
		vector<int> keysXY = kd2.DistinctKeys(50); //Generating nodes with unique x,y keys
		node->x = keysXY.at(0);
		node->y = keysXY.at(1);

		node->value = i;
		node->multiKeys.push_back(node->x);
		node->multiKeys.push_back(node->y);
		kd2.Insert(node);
		countKD++;
	}	

	//for the 200th node
	cout << setw(20) << nodeCountKD << setw(15) << kd2.Height(kd2.root) << setw(15) << log2(countKD) << setw(15) << sqrt(countKD);
	cout << endl;

	//-----------------------------TEST CASE #5-----------------------------------
	cout << "\n\n=============================================================\n";
	cout << "\t\tTEST CASE #5\n";
	cout << "=============================================================\n";
	
	BST bst5;
	vector<BSTNode*> list5; //List for Test Case 5
	for (int i = 0; i < 10; i++)
	{
		BSTNode* node = new BSTNode();
		int rand = bst5.DistinctKeys(10); //generating distinct random numbers
		vector<int> kv = list1.at(rand); //retrieving node values from list1 based on random number generation
		node->key = kv.at(0);
		node->value = kv.at(1);
		bst5.Insert(node);
		cout << "Inserting a"<<i+1<<": [" << node->key << "," << node->value<< "]";
		list5.push_back(node);
		cout << endl;
	}

	cout << endl;
	cout << "Preorder Display Before Delete: ";
	bst5.PreorderDisplay(bst5.root);
	cout << endl << endl;
	bst5.showBST(bst5.root, "t5-a.dot"); //Creating dot file t5-a
	cout << "t5-a.dot File Created!!\n\n"; 

	cout << "Deleting a1(at the root): [" << list5.at(0)->key << "," << list5.at(0)->value << "]";
	bst5.DeleteNode(list5.at(0)); //Node deleted
	cout << endl << endl;
	cout << "Preorder Display After Delete: ";
	bst5.PreorderDisplay(bst5.root);
	bst5.showBST(bst5.root, "t5-b.dot"); //Creating dot file t5-b
	cout << "\n\nt5-a.dot File Created!!\n\n";



	//-----------------------------TEST CASE #6-----------------------------------
	cout << "\n\n=========================================================\n";
	cout << "\t\tTEST CASE #6\n";
	cout << "=============================================================\n";

	KDTree kd3;
	vector<KDNode*> list6; //List for test case 6
	for (int i = 0; i < 10; i++)
	{
		KDNode* node = new KDNode();
		int rand = kd3.DistinctRandomNumbers(10); //Generating random numbers
		vector<int> kv = list2.at(rand); //Selecting random node from list2
		node->x = kv.at(0);
		node->y = kv.at(1);
		node->value = kv.at(2);
		node->multiKeys.push_back(node->x);
		node->multiKeys.push_back(node->y);
		cout << "Inserting b" << i + 1 << ": [" << node->x << "," << node->y<<","<<node->value << "]";
		kd3.Insert(node);
		list6.push_back(node);
		cout << endl;
	}
	cout << "\nPreorder Display Before Delete: ";
	kd3.PreorderDisplay(kd3.root);
	kd3.showKD(kd3.root, "t6-a.dot"); //Creating dot file t6-a
	cout << "\n\nt6-a.dot File Created!!\n\n";

	cout << "Deleting b1(at the root): [" << list6.at(0)->x << "," << list6.at(0)->y<<","<<list6.at(0)->value << "]";
	kd3.DeleteNode(kd3.root, 0);

	cout << "\n\nPreorder Display After Delete: ";	
	kd3.PreorderDisplay(kd3.root);
	kd3.showKD(kd3.root, "t6-b.dot"); //Creating dot file t6-b
	cout << "\n\nt6-b.dot File Created!!\n\n";

	//-----------------------------TEST CASE #7-----------------------------------
	cout << "\n\n=============================================================\n";
	cout << "\t\tTEST CASE #7\n";
	cout << "=============================================================\n";
	keys.clear();
	keys.push_back(0); // for k_0
	BST bst7;
	vector<vector<int> > list7; //list for test case 7
	int k = 1;
	for (int i = 1; i <= 20; i++)
	{
		BSTNode* node = new BSTNode();
		if (k == 1) //for n==1
			node->key = 1000;			
		else //for n>=2
			node->key = (keys.at(k - 2) + keys.at(k - 1)) / 2;

		keys.push_back(node->key);
		node->value = i;
		cout << "Inserting: [" << node->key << "," << node->value << "]\n";
		bst7.Insert(node);
		vector<int> kv;
		kv.push_back(node->key);
		kv.push_back(node->value);
		list7.push_back(kv);
		k++;
		if (k == 11)
		{ //start of k1,d11 insertion
			k = 1;
			keys.clear();
			keys.push_back(0);
		}
	}
	cout << "==============================================================================================================\n";
	cout << "\tstage|" << "\tData Item At Root|" << "\tThe root(after deletion)|" << "\tSearch for data item with key\n";
	cout << "==============================================================================================================\n";
	for (int i = 0; i < 20; i++)
	{
		if (i == 11)//dot file right afte stage 10
			bst7.showBST(bst7.root, "t7.dot");

		int keyToSearch = bst7.root->key;
		cout << "\t" << i <<"\t["<<bst7.root->key<<","<<bst7.root->value<<"]";
		bst7.DeleteNode(bst7.root);
		if (bst7.root != NULL)
		{
			cout << setw(20) << "[" << bst7.root->key << "," << bst7.root->value << "]";
			BSTNode* nodeFound=bst7.SearchNode(bst7.root, keyToSearch);
			if (nodeFound != NULL)
				cout << setw(30) << "[" << nodeFound->key << "," << nodeFound->value << "]";
			else
				cout << setw(35) << "NIL";
		}			
		else
			cout << setw(25) << "NIL" <<setw(35)<<"NIL";
		cout << endl;
	}
	cout << "\n\nt7.dot file created after stage 10";


	//-----------------------------TEST CASE #8-----------------------------------
	cout << "\n\n=============================================================\n";
	cout << "\t\tTEST CASE #8\n";
	cout << "=============================================================\n";

	KDTree kd4;

	vector<vector<int> > list8;
	vector<int> keyxT8;
	keyxT8.push_back(0);

	for (int i = 1; i <= 6; i++)
	{
		//Creating list l1 to l6
		vector<int> item;
		int x, y, v;
		if (i == 1)
			x = 500;
		else
			x = (keyxT8.at(i - 2) + keyxT8.at(i - 1)) / 2;
		y = 500 - x;
		v = i;
		keyxT8.push_back(x);
		item.push_back(x);
		item.push_back(y);
		item.push_back(v);
		list8.push_back(item);
	}

	int c = 1;
	for (int i = 7; i <= 12; i++)
	{
		//Creating list l7 to l12
		vector<int> item;
		int x, y, v, cx;
		x = (keyxT8.at(i - 2) + keyxT8.at(i - 1)) / 2; //x7...x12
		keyxT8.push_back(x);
		y = 500 - x;
		v = i;
		cx = keyxT8.at(c);
		c++;
		item.push_back(cx);
		item.push_back(y);
		item.push_back(v);
		list8.push_back(item);
	}
	int cx = 7;
	int cy = 1;
	for (int i = 13; i <= 18; i++)
	{
		//Creating list l13 to l18
		vector<int> item;
		int x, y, v;
		x = keyxT8.at(cx);
		y = 500 - keyxT8.at(cy);
		v = i;
		item.push_back(x);
		item.push_back(y);
		item.push_back(v);

		list8.push_back(item);
		cx++;
		cy++;
	}

	for (int i = 0; i < 18; i++)
	{
		//Inserting nodes by retrieving node values from list8
		KDNode* node = new KDNode();
		node->x = list8.at(i).at(0);
		node->y = list8.at(i).at(1);
		node->value = list8.at(i).at(2);
		node->multiKeys.push_back(node->x);
		node->multiKeys.push_back(node->y);
		cout << "Inserting: [" << node->x << "," << node->y << "," << node->value << "]\n";
		kd4.Insert(node);
	}
	cout << endl;
	int i = 0;

	while (kd4.root != NULL)
	{
		if (i == 6)
			kd4.showKD(kd4.root, "t8-a.dot");	//Creating dot file t8-a
		if (i == 12)
			kd4.showKD(kd4.root, "t8-b.dot");	//Creating dot file t8-b
	
		//Deleting root node
		cout<<"Deleting Node at root: [" << kd4.root->x << "," << kd4.root->y << "," << kd4.root->value << "]\n";
		kd4.DeleteNode(kd4.root, 0);

		//Searching for the nodes in list8
		cout<<"Searching for [" << list8.at(i).at(0) << "," << list8.at(i).at(1) << "," << list8.at(i).at(2) << "] ....... \n";
		if (kd4.SearchNode(kd4.root, list8.at(i), 0))
		{	//Node Found
			cout << "Found: [" << list8.at(i).at(0) << "," << list8.at(i).at(1) << "," << list8.at(i).at(2) << "] ******************* \n";
		}
		else
		{   //Node not found
			cout << "Not Found\n";
		}
		i++;
		cout << endl;
	}



	cout << endl;
	cout << endl;
    return 0;
}

