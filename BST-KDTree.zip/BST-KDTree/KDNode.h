#ifndef KDNODE_H
#define KDNODE_H
//The above statements act as a guard to avoid including this header file again and again

#include <iostream>
#include <cstdlib>
#include <vector>

using namespace std;
class KDNode {
public:
	int x; //x key
	int y; //y key
	vector<int> multiKeys; //x,y keys stored in a vector
	int value; //value

	KDNode* left; //left node
	KDNode* right; //right node
	KDNode* parent; //parent
	

	KDNode();
};





#endif