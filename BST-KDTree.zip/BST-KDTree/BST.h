#ifndef BST_H
#define BST_H
//The above statements act as a guard to avoid including this header file again and again

#include <iostream>
#include <cstdlib>
#include "BSTNode.h"
#include<vector>
using namespace std;
class BST {
public:
	BSTNode* root; //Defines the root fo the tree
	vector<int> distinctKeys; //

	BST(); //Constructor
	void Insert(BSTNode*); //inserts a node to the tree
	int Height(BSTNode*); //calculates the height of the tree
	BSTNode* BSTMinimum(BSTNode*); //Minimum key node
	void DeleteNode(BSTNode*); //Deletes a node from the tree
	void BSTTransplant(BSTNode*, BSTNode*); //Exchanges node to be deleted with next successor
	void PreorderDisplay(BSTNode*); //preorder display
	BSTNode* SearchNode(BSTNode*,int); //searches for a node
	void InorderDisplay(BSTNode*);//inorder display
	
	int DistinctKeys(int); //function that removes distinct keys

	/*
		Functions that creat dot files
	*/
	void showBST(BSTNode*, string); 
	void PrintDot(BSTNode*, FILE*);
	void PrintDotNull(string, int, FILE*);
};
#endif