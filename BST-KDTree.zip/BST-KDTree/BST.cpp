
#include "BST.h"
#include <sstream>
#include <stdio.h>

//Constructor for BST Tree
BST::BST()
{
	root = NULL;
}

//Constructor for BST Node
BSTNode::BSTNode()
{
	left = NULL;
	right = NULL;
	parent = NULL;
}

//Function to Insert a node to a BST Tree
void BST::Insert(BSTNode* newNode)
{
	BSTNode *tempParent = NULL;
	BSTNode *curr = root;
	while (curr != NULL)
	{
		tempParent = curr;
		if (newNode->key <= curr->key) //insertion in left subtree
			curr = curr->left;
		else
			curr = curr->right;		//insertion in right subtree
	}
	newNode->parent = tempParent;
	if (tempParent == NULL)
		root = newNode;
	else if (newNode->key <= tempParent->key)
		tempParent->left = newNode;
	else
		tempParent->right = newNode;

}

//Inorder Display of the BST Tree
void BST::InorderDisplay(BSTNode* root)
{
	if (root != NULL)
	{		
		InorderDisplay(root->left);		
		cout << "[" << root->key << "," << root->value << "] ";
		InorderDisplay(root->right);
	}
}

//Preorder Display of the BST Tree
void BST::PreorderDisplay(BSTNode* root)
{
	if (root != NULL)
	{
		cout << "[" << root->key << "," << root->value << "] ";
		PreorderDisplay(root->left);
		PreorderDisplay(root->right);
	}
}

//Function that calculates the height of the BST Tree
int BST::Height(BSTNode* currRoot)
{
	if (currRoot == NULL) //return -1 if root is null
		return -1;
	else
	{
		int hLeft = Height(currRoot->left); //Height of left subtree
		int hRight = Height(currRoot->right); //Height of right subtree

		if (hLeft > hRight)
			return hLeft + 1;	//return left subtree height + 1 if its bigger than right subtree height
		else
			return hRight + 1;	//else return right subtree height + 1
	}		
}

//Function used to generate random distinct keys
int BST::DistinctKeys(int range)
{
	int flag = true;
	int key = 0;
	while (flag)
	{
		flag = false;
		key = rand() % range;
		for (int i = 0; i < distinctKeys.size(); i++)
		{
			if (key == distinctKeys.at(i))
			{
				flag = true;
				break;
			}
		}
	}
	distinctKeys.push_back(key);
	return key;
}

//Function that finds the Minimum Node from a given Subtree
BSTNode* BST::BSTMinimum(BSTNode* node)
{ //returns the left most node in a tree
	while (node->left != NULL)
		node = node->left;
	return node;
}

//Function that deletes a node
void BST::DeleteNode(BSTNode* z)
{
	if (z->left == NULL) //if node to be deleted has no left child
		BSTTransplant(z, z->right);
	else if (z->right == NULL) //if node to be deleted has no right child
		BSTTransplant(z, z->left);
	else {	//if node to be deleted has both left and right child
		BSTNode* y = BSTMinimum(z->right); //finds the next successor in the right subtree
		if (y->parent != z)
		{ //if z is not the parent of its successor, we call the trnsplant function
			BSTTransplant(y, y->right);
			y->right = z->right;
			y->right->parent = y;
		}
		BSTTransplant(z, y);
		y->left = z->left;
		y->left->parent = y;
	}
}

//Function that replaces the node to be deleted with the node to replace it
void BST::BSTTransplant(BSTNode* u, BSTNode* v)
{
	if (u->parent == NULL) //if u is root node
		root = v;
	else if (u == u->parent->left) //if u is left child
		u->parent->left = v;
	else
		u->parent->right = v; //if u is right child

	if (v != NULL)
		v->parent = u->parent;
}

//Search for a node
BSTNode* BST::SearchNode(BSTNode* node, int key)
{
	if (node == NULL || key == node->key)
		return node;

	if (key < node->key) //if key is less than node, we search left subtree
		return SearchNode(node->left, key);
	else 
		return SearchNode(node->right, key);
}

//Prints a null node in the dot file. represented by DOT
void BST::PrintDotNull(string key, int nullcount, FILE* stream)
{
	fprintf(stream, "    null%d [shape=point];\n", nullcount);
	fprintf(stream, "    \"%s\" -> null%d;\n", key.c_str(), nullcount);
}

//Prints a node in the dot file. 
void BST::PrintDot(BSTNode* node, FILE* stream)
{
	static int nullcount = 0;

	if (node->left != NULL)
	{
		ostringstream convert; 
		convert << node->key << "," << node->value;
		string k1 = convert.str(); //converts integers to strings, to display them in the node
		convert.str("");
		convert << node->left->key << "," << node->left->value;
		string k2 = convert.str().c_str();
		fprintf(stream, "    \"%s\" -> \"%s\";\n", k1.c_str(), k2.c_str());
		PrintDot(node->left, stream);
	}
	else
	{
		ostringstream convert;
		convert << node->key << "," << node->value;
		string k1 = convert.str();
		PrintDotNull(k1, nullcount++, stream);
	}

	if (node->right != NULL)
	{
		ostringstream convert;
		convert << node->key << "," << node->value;
		string k1 = convert.str();
		convert.str("");
		convert << node->right->key << "," << node->right->value;
		string k2 = convert.str();
		fprintf(stream, "    \"%s\" -> \"%s\";\n", k1.c_str(), k2.c_str());
		PrintDot(node->right, stream);
	}
	else
	{
		ostringstream convert;
		convert << node->key << "," << node->value;
		string k1 = convert.str();
		PrintDotNull(k1, nullcount++, stream);
	}


}

//Show function that creates a dot file
void BST::showBST(BSTNode* root, string fileName)
{
	FILE* stream = fopen(fileName.c_str(), "w"); //creating file to write
	fprintf(stream, "digraph BST {\n"); 
	fprintf(stream, "    node [fontname=\"Arial\"];\n");

	if (root == NULL)
		fprintf(stream, "\n"); //if root is null
	else if (root->right == NULL && root->left == NULL)
	{ //if node is a leaf node
		ostringstream convert;
		convert << root->key << "," << root->value;
		string k = convert.str();
		fprintf(stream, "    \"%s\";\n", k.c_str());
	}
	else
		PrintDot(root, stream); 

	fprintf(stream, "}\n");
	fclose(stream);
}
