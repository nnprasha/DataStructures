======================================================================================================
								README.TXT
======================================================================================================

Implementations of KDTree (2d) and Binary Search Trees
--------------------------------------------------------------------------------------------
To Implement all the operations specified in the assignment, I have used 3 .cpp files and 4 .h files.
-> main.cpp
	This file includes the main function of the program. In the main function, I have defined the 8 different test cases to execute. 
		
	All the input is provided inside the main function. 	
	rand() is used to generate random numbers for input. srand() is also used so that new set of random nubers are generated each time the program executes.
	Header files used - 
		<iostream> - for cout/cin i.e input/output
		time.h- for srand()
		sstream for ostringstream
		
	I have defined classes for the Binary search tree (BSTNode and BST). BSTNode defines a node for Binary Search Tree. BST defines an entire Binary Search Tree. 
	I have defined classes for KD Tree (KDNode and KDTree). KDNode defines a single node of the KDTree. KDTree defines an entire KDTree. 
				-------------------------------------------------------------------------------------------------------				
->BST.cpp
	This is an implementation file that defines all the functions of the BST class. 
	
	void Insert(BSTNode*) -------- > inserts a node to the tree
	//
	int Height(BSTNode*) --------- > calculates the height of the tree
	//
	BSTNode* BSTMinimum(BSTNode*) ----------> Returns the node with the Minimum key i.e the left most left node of the tree
	//
	void DeleteNode(BSTNode*) --------- > Deletes a node from the tree
	//
	void BSTTransplant(BSTNode*, BSTNode*)-------- > Exchanges node to be deleted with next successor
	//
	void PreorderDisplay(BSTNode*) -------- > preorder display
	//
	BSTNode* SearchNode(BSTNode*,int) -------- > searches for a node
	//
	void InorderDisplay(BSTNode*) -------- > inorder display
	
		--------------------------------------------------------------------------------------------------------------
->KDTree.cpp
	This is an implementation file that defines all the functions of the KDTree Class. 	
	
	void Insert(KDNode*) -------> Inserts a node to the KDTree
	void InorderDisplay(KDNode*) ------> Inorder Display
	void PreorderDisplay(KDNode*) -------> Preorder display
	int Height(KDNode*) -----> Returns the Height of the tree
	vector<int> DistinctKeys(int) -----> function that returns a set of distinct (x,y) keys
	void DeleteNode(KDNode*,int) --------> Deletes a node from the tree
	bool SearchNode(KDNode*, vector<int>, int) -------> Searches for a node from the given tree
	bool ComparePoints(KDNode*, vector<int>) -------> Compares two nodes
	int Depth(KDNode*) ------> returns the depth of a node
	KDNode* Smallest(KDNode*, int, int) -------> returns the node with the smallest keys
	int DistinctRandomNumbers(int) ------> returns Distinct Random numbers
	------------------------------------------------------------------------------------------------------------
->BSTNode.h
	Defines the BSTNode Class. 
	defines a single node for BST. 
			------------------------------------------------------------------------------------------------------------
->BST.h
	Defines the BST Class.
	Defines a binary search tree. Declares all the BST Functions mentioned above. 
	defines a root variable which species the root of the tree. 
            ------------------------------------------------------------------------------------------------------------
->KDNode.h
	Defines the KDNode class. 
	Defines a single node for KDTree. 
			------------------------------------------------------------------------------------------------------------
->KDTree.h
	Defines the KDTree Class
	Defines a KD tree. Declares all the KDTree functions mentioned above. 
	defines a root variable which specifies the root of the tree. 
	--------------------------------------------------------------------------------------------------------------------
	
The functions defined below are used to create a Dot File. 

	void showKD(KDNode*, string) ------> this function is called from main. It creates the dot file and calls the other two functions described below
										to create the tree nodes in the dot files. 
										
	void PrintDot(KDNode*, FILE*); ------> This function creates a node that is displayed as a part of the tree in the dot files. 
	
	void PrintDotNull(string, int, FILE*) -----> This function creates a null node (point shape) to specify null in the dot files. 
	
	Also, I have used sstream lib to convert intergers to their respective string representation to display in the graphs. FILESTREAM is used to open and write to a file. 
References: 
	Web: 
	--> http://eli.thegreenplace.net/2009/11/23/visualizing-binary-trees-with-graphviz
	--> http://geeksforgeeks.com
	--> http://stackoverflow.com
	
	Class Texts:
	--> Data Structures and Algorithms in c++ by Adam Drozdek
	--> CLRS-Introduction to algorithms-3rd edition
	
	=======================================================================================================================================================