#include "SingleList.h"
#include <iostream>
using namespace std;


// Defining the Constructor for SingleNode Class
SingleNode::SingleNode()
{
	next = NULL; //initializing the pointer to next variable with null
	value = 0; //initially the value will be 0
}

//Defining the Constructor for SingleList Class
SingleList::SingleList()
{
	head = NULL; //Initially head is NULL i.e the list is empty
}

//------------------Function to add nodes to the list--------------
void SingleList::appendValueToList(int data)
{
	SingleNode *node = new SingleNode(); //creating a new node with value=0 and next=NULL
	node->value = data;  // Node value changed to data

	// Checking if list is NULL
	if (head == NULL)
	{
		head = node; //Making the new node the first node of the list, and assiging head to it. 
	}
	else 
	{	//if list is not NULL
		
		SingleNode *current; //Pointer to the SingleNode 

		// Function to traverse through the list. Iteration stops when current points to the last node in the list
		for (current = head; current->next != NULL; current = current->next);
			current->next = node; //The new Node is added in the end of the list. 
	}
}

//--------------Function to Delete the list after every test case execution----------------
void SingleList::clearList()
{
	// Checking if head is not NULL i.e list is not empty
	if (head != NULL)
	{	
		SingleNode *current = head; // Defines a pointer "current" that points to the head of the list. 

		while (current != NULL)
		{	
			head = head->next;	//Increments head to point to the next node
			delete current;	// Deletes current node from the list
			current = head;	//	makes current again point to the next node i.e the next node
		}

		head = NULL;	// After all the nodes are deleted, Head is again made NULL to show that list is empty. 
	}
	else
	{
		cout << "\n\nLIST IS EMPTY\n\n";
	}
}

//-----------Fucntion to display values of nodes-------------==
void SingleList::linkListTraverse()
{
	int i = 0;
	for (SingleNode *current = head; current != NULL; current = current->next)
	{
		cout << current->value << " => ";
		i++;
		if (i == 4){	//Displaying 4 nodes per line
			cout << endl;
			i = 0;
		}
	}
	cout <<"NULL"<<endl;

}

//----------function to Display list in parts of 2 i.e first half and second half
void SingleList::DisplayListInParts()
{
	int i = 0;
	int count = 0;
	int half = size() / 2;
	int mid = 0;
	if (size() % 2 == 0)
	{	// if length of list is even 
		mid = half;
	}
	else
	{	// if length of list is odd
		mid = half + 1;
	}
	cout << "**********First Half**********" << endl;
	for (SingleNode *current = head; current != NULL; current = current->next)
	{
		
		cout << current->value << " => ";	
		i++;
		count++;
		if (i == 4) {	//Displaying 4 nodes per line
			cout << endl;
			i = 0;
		}
		if (count == mid)
		{	//When count == mid, we start displaying the second half of the list. 
			cout << endl << "**********Second Half********" << endl;
			i = 0;
		}
	}
	cout << "NULL"<<endl;
}

// ------- Function to calculate the size of the list--------------
int SingleList::size()
{
	int count = 0;
	for (SingleNode *current = head; current != NULL; current = current->next)
		count++;	// iterates through the list and incements count for each node visited
	return count;	// returns the length of the list
}

//------------Question1: Function to sort list in ascending order in a pair of FOUR-------------
void SingleList::pairOfFour()
{
	int sizeOfList = size();	//Calculates the length of the list
	int j = 0;
	SingleNode *current;
	SingleNode *tempHead = head; //Temporary head of the list. 
	SingleNode *temp;
	SingleNode *prev = NULL;
	SingleNode *beforeTempHead = NULL;	//Pointer to a node just before the tempHead Node

	//-------------------START OF **BLOCK A**-------------------
	if (head != NULL)
	{ //Only if list is not empty
		for (int k = 0; k < sizeOfList / 4; k++)
		{	//loop iterations are equal to no. of concurrent pair of four nodes in the list. 
			for (int i = 0; i < 4; i++)
			{
				if (k == 0)
				{
					prev = NULL;	//initially previous is NULL
				}
				else
				{
					prev = beforeTempHead;
					tempHead = beforeTempHead->next;
				}
				for (current = tempHead, j = 0; j < 3; current = current->next, j++)
				{

					temp = current->next;
					if (temp->value < current->value)
					{	//Code to swap two **NODES**
						current->next = temp->next;
						temp->next = current;
						if (prev == NULL)
						{
							head = temp;
							tempHead = head;
						}
						else
						{
							prev->next = temp;
						}
						current = temp;
					}
					prev = current;
				}
			}
			prev = prev->next;
			beforeTempHead = prev;
			tempHead = prev->next;
		}

		//-------------END OF **BLOCK A**----------------

		//------------START OF **BLOCK B**---------------
		if (sizeOfList % 4 != 0)
		{
			//For the remaining elements that are not part of the pair of four i.e the elements remaining in the end of the list. 
			for (int i = 0; i < sizeOfList % 4; i++)
			{
				prev = beforeTempHead;
				for (SingleNode *current = tempHead; current->next != NULL; current = current->next)
				{
					temp = current->next;
					if (temp->value < current->value)
					{
						//Code to swap two **NODES**
						current->next = temp->next;
						temp->next = current;
						prev->next = temp;
						if (prev == beforeTempHead)
							tempHead = temp;
						current = temp;
					}
					prev = current;
				}

			}
		}
	}
	else {
		cout << "\n\nLIST IS EMPTY!!\n\n";
	}
	//--------------END OF **BLOCK B**------------
}

//------------Question2: Function to reverse a linked list----------
void SingleList::reverse()
{
	//checking if list is NULL
	if (head == NULL)
		cout << "\n\nList is empty!!!\n\n";
	else
	{	//if list is not NULL

		SingleNode *current = head;	//"current" points to the heaed of the list
		SingleNode *prev = NULL; //specifies the previous node
		SingleNode *nextNode; //specifies the next node from the current node
		
		//-------START OF **BLOCK C**------------
			//Snippet to reverse the list
			while (current != NULL)
			{	//Executes till the current node doesnt become NULL
				nextNode = current->next;	//nextNode points to the next node
				current->next = prev;	//current node now points to its previous node
				prev = current;	//previous node now becomes the current node
				current = nextNode;	//current node now becomes the nextNode. 
			}
			head = prev;	//After the loop executes, prev will point to the first node. So we make head point to prev i.e the first node
		//-------END OF **BLOCK C**--------------
	}
	
}

//---------------Question3: Function to Shuffle a linked list---------------
void SingleList::shuffle()
{
	int half = size() / 2; // half-lenght of the list
	int countToSecondHalf = 0; //will give the position of the first variable of second half

	SingleNode *FirstHalfPointer = head; //pointer to the first half of the list
	SingleNode *SecondHalfPointer = NULL; //pointer to the second half of the list
	SingleNode *tempFirstHalf = NULL;	
	SingleNode *tempSecondHalf = NULL;	
	if (head != NULL)
	{
		//------Start of **BLOCK D**----------
		if (size() % 2 == 0)
		{	//If length of the list is even
			countToSecondHalf = half;
		}
		else
		{	//If length of the list is odd
			countToSecondHalf = half + 1;
		}
		//-------END OF **BLOCK D**------------

		int i = 0;
		SingleNode *current;
		for (i = 0, current = head; i < countToSecondHalf; current = current->next, i++);
		SecondHalfPointer = current;	//Second Half Pointer will point to the first node in the second half of the list

		if (size() > 2) //Because shuffle will only take place if length is more than 2
		{
			//Snippet to shuffle the list
			//---------------- START of **BLOCK E**--------------
			for (int i = 0; i < countToSecondHalf - 1; i++)
			{
				tempFirstHalf = FirstHalfPointer->next;
				tempSecondHalf = SecondHalfPointer->next;
				FirstHalfPointer->next = SecondHalfPointer;
				SecondHalfPointer->next = tempFirstHalf;
				SecondHalfPointer = tempSecondHalf;
				FirstHalfPointer = tempFirstHalf;
			}
			tempFirstHalf->next = tempSecondHalf;
			//-----------END OF **BLOCK E**---------------------
		}
	}
	else
	{
		cout << "\n\nLIST IS EMPTY\n\n";
	}
}
