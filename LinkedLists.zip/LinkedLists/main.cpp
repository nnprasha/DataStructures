// Assignment-1.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include<time.h>
#include "SingleList.h"
#include "DoubleList.h"
using namespace std;


int main()
{
	
	SingleList singleList;
	
	DoubleList doubleList;

	srand(time(NULL));	//Used to generate new random numbers each time program is executed (change the seed of random numbers everytime)

	/* ********************TEST CASE 1******************* */
		cout << "\t\t############ TEST CASE 1: TEAM OF FOUR FOR **SINGLY LINKED LIST** (INPUT: S1)#############\n\n";
		for (int i = 1; i <= 100; i++)
			singleList.appendValueToList(i);

		cout << "*******LIST BEFORE THE OPERATION***********" << endl;
		singleList.linkListTraverse();	//Function to display the result

		//calling function to execute pair of four operation on singly linked list
		singleList.pairOfFour();

		cout << "\n********LIST AFTER THE OPERATION************" << endl;
		singleList.linkListTraverse();

		//deleting the list
		singleList.clearList();

		cout << "\n ------------------------------------------------------------------------------------- \n \n";
	/* ********************TEST CASE 2******************* */
		cout << "\t\t############ TEST CASE 2: TEAM OF FOUR FOR **DOUBLY LINKED LIST** (INPUT: S1) #############\n\n"<<endl;
		for (int i = 1; i <= 100; i++)
			doubleList.appendValueToList(i);

		cout << "*******LIST BEFORE THE OPERATION***********"<<endl;
		doubleList.linkListTraverse();

		//calling function to execute pair of four operation on double linked list
		doubleList.pairOfFour();

		cout << "\n********LIST AFTER THE OPERATION************" << endl;
		doubleList.linkListTraverse();	

		//deleting the list 
		doubleList.clearList();

		cout << "\n ------------------------------------------------------------------------------------- \n \n";
	/* ******************TEST CASE 3*********************** */
		cout << "\t\t############ TEST CASE 3: TEAM OF FOUR FOR **SINGLY LINKED LIST** (INPUT: S2)#############\n\n" << endl;
		for (int i = 1; i <= 100; i++)
			singleList.appendValueToList(rand() % 1000);	//Adding random integers(0-999) to the list

		cout << "*******LIST BEFORE THE OPERATION***********" << endl;
		singleList.linkListTraverse();

		//calling function to execute pair of four operation on singly linked list
		singleList.pairOfFour();

		cout << "\n********LIST AFTER THE OPERATION************" << endl;
		singleList.linkListTraverse();

		//deleting the list
		singleList.clearList();
		cout << "\n ------------------------------------------------------------------------------------- \n \n";
	/* ********************TEST CASE 4******************* */
		cout << "\t\t############ TEST CASE 4: TEAM OF FOUR FOR **DOUBLY LINKED LIST** (INPUT: S2) #############\n\n" << endl;
		for (int i = 1; i <= 100; i++)
			doubleList.appendValueToList(rand() % 1000);

		cout << "*******LIST BEFORE THE OPERATION***********" << endl;
		doubleList.linkListTraverse();

		//calling function to execute pair of four operation on double linked list
		doubleList.pairOfFour();

		cout << "\n********LIST AFTER THE OPERATION************" << endl;
		doubleList.linkListTraverse();

		//deleting the list 
		doubleList.clearList();
		cout << "\n ------------------------------------------------------------------------------------- \n \n";
				
	/* ********************TEST CASE 5******************* */
		cout << "\t\t############ TEST CASE 5: REVERSE FOR **SINGLY LINKED LIST** (INPUT: S1)#############\n\n" << endl;
		for (int i = 1; i <= 100; i++)
			singleList.appendValueToList(i);

		cout << "*******LIST BEFORE THE OPERATION***********" << endl;
		singleList.linkListTraverse();

		//calling function to execute pair of four operation on singly linked list
		singleList.reverse();

		cout << "\n********LIST AFTER THE OPERATION************" << endl;
		singleList.linkListTraverse();

		//deleting the list
		singleList.clearList();
		cout << "\n ------------------------------------------------------------------------------------- \n \n";

	/* ********************TEST CASE 6******************* */
		cout << "\t\t############ TEST CASE 6: REVERSE FOR **DOUBLY LINKED LIST** (INPUT: S1) #############\n\n" << endl;
		for (int i = 1; i <= 100; i++)
			doubleList.appendValueToList(i);

		cout << "*******LIST BEFORE THE OPERATION***********" << endl;
		doubleList.linkListTraverse();

		//calling function to execute pair of four operation on double linked list
		doubleList.reverse();

		cout << "\n********LIST AFTER THE OPERATION************" << endl;
		doubleList.linkListTraverse();

		//deleting the list 
		doubleList.clearList();
		cout << "\n ------------------------------------------------------------------------------------- \n \n";
	/* ******************TEST CASE 7*********************** */
		cout << "\t\t############ TEST CASE 7: REVERSE FOR **SINGLY LINKED LIST** (INPUT: S2)#############\n\n" << endl;
		for (int i = 1; i <= 100; i++)
			singleList.appendValueToList(rand() % 1000);

		cout << "*******LIST BEFORE THE OPERATION***********" << endl;
		singleList.linkListTraverse();

		//calling function to execute pair of four operation on singly linked list
		singleList.reverse();

		cout << "\n********LIST AFTER THE OPERATION************" << endl;
		singleList.linkListTraverse();

		//deleting the list
		singleList.clearList();
		cout << "\n ------------------------------------------------------------------------------------- \n \n";
	/* ********************TEST CASE 8******************* */
		cout << "\t\t############ TEST CASE 8: REVERSE FOR **DOUBLY LINKED LIST** (INPUT: S2) #############\n\n" << endl;
		for (int i = 1; i <= 100; i++)
			doubleList.appendValueToList(rand() % 1000);

		cout << "*******LIST BEFORE THE OPERATION***********" << endl;
		doubleList.linkListTraverse();

		//calling function to execute pair of four operation on double linked list
		doubleList.reverse();

		cout << "\n********LIST AFTER THE OPERATION************" << endl;
		doubleList.linkListTraverse();

		//deleting the list 
		doubleList.clearList();
		cout << "\n ------------------------------------------------------------------------------------- \n \n";
	/* ********************TEST CASE 9******************* */
		cout << "\t\t############ TEST CASE 9: SHUFFLE FOR **SINGLY LINKED LIST** (INPUT: S1)#############\n\n" << endl;
		for (int i = 1; i <= 100; i++)
			singleList.appendValueToList(i);
		
		//Calling fuction to display the lists in parts of two
		cout << "***********BEFORE THE OPERATION**************" << endl;
		singleList.DisplayListInParts();

		//calling function to execute pair of four operation on singly linked list
		singleList.shuffle();

		cout << "\n********LIST AFTER THE OPERATION************" << endl;
		singleList.linkListTraverse();

		//deleting the list
		singleList.clearList();
		cout << "\n ------------------------------------------------------------------------------------- \n \n";

	/* ********************TEST CASE 10******************* */
		cout << "\t\t############ TEST CASE 10: SHUFFLE FOR **DOUBLY LINKED LIST** (INPUT: S1) #############\n\n" << endl;
		for (int i = 1; i <= 100; i++)
			doubleList.appendValueToList(i);

		//Calling fuction to display the lists in parts of two
		cout << "***********BEFORE THE OPERATION**************" << endl;
		doubleList.DisplayListInParts();
		
		//calling function to execute pair of four operation on double linked list
		doubleList.shuffle();

		cout << "\n********LIST AFTER THE OPERATION************" << endl;
		doubleList.linkListTraverse();

		//deleting the list 
		doubleList.clearList();
		cout << "\n ------------------------------------------------------------------------------------- \n \n";
	/* ******************TEST CASE 11*********************** */
		cout << "\t\t############ TEST CASE 11: SHUFFLE FOR **SINGLY LINKED LIST** (INPUT: S2)#############\n\n" << endl;
		for (int i = 1; i <= 100; i++)
			singleList.appendValueToList(rand() % 1000);

		//Calling fuction to display the lists in parts of two
		cout << "***********BEFORE THE OPERATION**************" << endl;
		singleList.DisplayListInParts();
		
		//calling function to execute pair of four operation on singly linked list
		singleList.shuffle();

		cout << "\n********LIST AFTER THE OPERATION************" << endl;
		singleList.linkListTraverse();

		//deleting the list
		singleList.clearList();
		cout << "\n ------------------------------------------------------------------------------------- \n \n";

	/* ********************TEST CASE 12******************* */
		cout << "\t\t############ TEST CASE 12: SHUFFLE FOR **DOUBLY LINKED LIST** (INPUT: S2) #############\n\n" << endl;
		for (int i = 1; i <= 100; i++)
			doubleList.appendValueToList(rand() % 1000);

		//Calling fuction to display the lists in parts of two
		cout << "***********BEFORE THE OPERATION**************" << endl;
		doubleList.DisplayListInParts();

		//calling function to execute pair of four operation on double linked list
		doubleList.shuffle();

		cout << "\n********LIST AFTER THE OPERATION************" << endl;
		doubleList.linkListTraverse();

		//deleting the list 
		doubleList.clearList();
		cout << "\n ------------------------------------------------------------------------------------- \n \n";
}

