#ifndef SINGLELIST_H
#define SINGLELIST_H
//The above statements act as a guard to avoid including this header file again and again

#include "SingleNode.h"
//class SingleList that defines a list
class SingleList
{
public:
	SingleNode *head; // Pointer to SingleNode. "head" will be used to point to the Head of the list i.e first element of the list. 
	SingleList(); //Default Constructor
	void appendValueToList(int); // Adds modes to the list
	void linkListTraverse(); // Traverses the list and displays the values in the nodes
	int size(); //specifies the current size of the linked list
	void pairOfFour(); // Question 1 
	void reverse(); // Question 2
	void shuffle(); // Question 3
	void clearList(); // Deletes the list after every test case execution. 
	void DisplayListInParts(); // Displays lists in part of 2, used to display list in Question 3
};
#endif // !SINGLELIST_H
