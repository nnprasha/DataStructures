#include "DoubleList.h"
#include <iostream>
using namespace std;

//Constructor of the DoubleNode class
DoubleNode::DoubleNode()
{
	next = NULL; //next pointer initialised to NULL
	prev = NULL; //previous pointer initialised to NULL
	value = 0;
}

//Constructor of the DoubleNode Class
DoubleList::DoubleList()
{
	head = NULL; //Head pointer initialised to NULL
}

//Function to add nodes to the list
void DoubleList::appendValueToList(int data)
{
	DoubleNode *node = new DoubleNode(); //Creating a new node
	node->value = data; 
	if (head == NULL)
	{	//Checking if the head is NULL i.e if list is empty
		head = node;	//Making the new node the first node of the list by making it the head node
	}
	else
	{	//Adding the node to the End of the list
		DoubleNode *current;
		for (current = head; current->next != NULL; current = current->next);

		current->next = node;
		node->prev = current;
		node->next = NULL;
	}
}

//function to delete the list after every test case execution
void DoubleList::clearList()
{
	if (head != NULL)
	{
		DoubleNode *current = head; //Current is pointed to the head of the list

		while (current != NULL)
		{	//Till the time the current node doest reach NULL
			head = head->next; //Head is pointed to its next node
			delete current;	//current is deleted
			current = head;	//current is again pointed to the head node. 
		}
		head = NULL;	//Head is made NULL i.e list has become  empty
	}
	else
	{
		cout << "\n\nLIST IS EMPTY\n\n";
	}
}

//Function to traverse through the list and display the node values
void DoubleList::linkListTraverse()
{
	int i = 0;
	for (DoubleNode *curr = head; curr != NULL; curr = curr->next)
	{
		cout << curr->value << " <=> ";
		i++;
		if (i == 4) {//Displaying 4 nodes per line
			cout << endl;
			i = 0;
		}
	}
	cout <<"NULL"<< endl;
}

//Function to traverse through the list and display the list in **PARTS OF 2** i.e first half and second half. Used with the shuffle function
void DoubleList::DisplayListInParts()
{
	int i = 0;
	int count = 0;
	int half = size() / 2;
	int mid = 0;
	if (size() % 2 == 0)
	{	//If length of the list is even
		mid = half;
	}
	else
	{	//if length of the list is odd
		mid = half + 1;
	}
	cout << "**********First Half**********"<<endl;
	for (DoubleNode *current = head; current != NULL; current = current->next)
	{
		cout << current->value << " <=> ";
		i++;
		count++;
		if (i == 4) {//Displaying 4 nodes per line
			cout << endl;
			i = 0;
		}
		if (count == mid)
		{	//when count == mid, the second half of the list starts displaying
			cout << endl << "**********Second Half********" << endl;
			i = 0;
		}

	}
	cout <<"NULL"<<endl;
}

//Function to calculate the length of the list
int DoubleList::size()
{
	int count = 0;
	for (DoubleNode *current = head; current != NULL; current = current->next)
		count++;
	return count;	//Returns the length of the list
}

//------------Question 1: Function to sort the list in ascending order in a **PAIR OF FOUR**-------------
void DoubleList::pairOfFour()
{
	int sizeOfList = size();
	int j = 0;
	DoubleNode *current;
	DoubleNode *tempHead = head; //temporary head
	DoubleNode *temp;
	DoubleNode *beforeTempHead = NULL;
	if (head != NULL)
	{
		//--------------START OF **BLOCK F**---------------------
		for (int k = 0; k < sizeOfList / 4; k++)
		{
			for (int i = 0; i < 4; i++)
			{
				for (current = tempHead, j = 0; j < 3; current = current->next, j++)
				{
					temp = current->next;
					if (temp->value < current->value)
					{

						current->next = temp->next;
						if (temp->next != NULL)
							temp->next->prev = current;
						temp->next = current;
						temp->prev = current->prev;
						current->prev = temp;
						if (temp->prev != NULL)
							temp->prev->next = temp;

						if (temp->prev == beforeTempHead)
						{
							if (k == 0)
							{
								head = temp;
								tempHead = head;
							}
							else {
								tempHead = temp;
							}

						}

						current = temp;
					}
				}

			}
			beforeTempHead = current;
			tempHead = beforeTempHead->next;
		}
		//---------------END OF **BLOCK F**---------------

		//---------------START OF **BLOCK G**-------------
		if (sizeOfList % 4 != 0)
		{

			for (int i = 0; i < sizeOfList % 4; i++)
			{
				tempHead = beforeTempHead->next;
				for (current = tempHead; current->next != NULL; current = current->next)
				{
					temp = current->next;
					if (temp->value < current->value)
					{
						current->next = temp->next;
						if (temp->next != NULL)
							temp->next->prev = current;
						temp->next = current;
						temp->prev = current->prev;
						current->prev = temp;
						if (temp->prev != NULL)
							temp->prev->next = temp;

						current = temp;
					}

				}
			}
		}
	}
	else
	{
		cout << "\n\nLIST IS EMPTY\n\n";
	}
	//-----------------END OF **BLOCK G**--------------
}

//----------Question 2: Function to reverse the nodes of a doubly linked list-------------
void DoubleList::reverse()
{
	if (head == NULL)
		cout << "List is empty";
	else {
		//----------START OF **BLOCK H**----------------
		DoubleNode *nextNode = NULL; //pointer to the next node of the current node
		DoubleNode *current = head;
		while (current->next != NULL)
		{
			nextNode = current->next;
			current->next = current->prev;
			current->prev = nextNode;
			current = nextNode;
		}
		current->next = current->prev;
		current->prev = NULL;
		head = current;
		//----------**END OF BLOCK H**-----------------
	}	
}

//---------Question 3: Function to Shuffle the doubly linked list
void DoubleList::shuffle()
{
	int half = size() / 2; // half-lenght of the list
	int countToSecondHalf = 0; //will give the position of the first variable of second half

	DoubleNode *FirstHalfPointer = head; //pointer to theh first half of the list
	DoubleNode *SecondHalfPointer = NULL; //pointer to the second half of the list
	DoubleNode *tempFirstHalf = NULL;
	DoubleNode *tempSecondHalf = NULL;

	if (head != NULL)
	{
		if (size() % 2 == 0)
		{	//if the list length is even
			countToSecondHalf = half;
		}
		else
		{	//if the list length is odd
			countToSecondHalf = half + 1;
		}

		int i = 0;
		DoubleNode *current;
		for (i = 0, current = head; i < countToSecondHalf; current = current->next, i++);
		SecondHalfPointer = current;	//SecondHalfPointer will point to the first node in the second half of the list

		if (size() > 2) //Because shuffle will only take place if length is more than 2
		{
			//---------START OF **BLOCK I**---------------
			for (int i = 0; i < countToSecondHalf - 1; i++)
			{
				tempFirstHalf = FirstHalfPointer->next;
				tempSecondHalf = SecondHalfPointer->next;
				FirstHalfPointer->next = SecondHalfPointer;
				SecondHalfPointer->prev = FirstHalfPointer;
				SecondHalfPointer->next = tempFirstHalf;
				tempFirstHalf->prev = SecondHalfPointer;

				FirstHalfPointer = tempFirstHalf;
				SecondHalfPointer = tempSecondHalf;
			}
			tempFirstHalf->next = tempSecondHalf;
			//----------END OF **BLOCK I**----------------
		}
	}
	else
	{
		cout << "\n\nLIST IS EMPTY\n\n";
	}
}