#ifndef DOUBLELIST_H
#define DOUBLELIST_H
//The above statements act as a guard to avoid including this header file again and again

#include "DoubleNode.h"
class DoubleList {
public:
	DoubleNode *head; // points to the head of the list
	DoubleList(); //default constructor
	void appendValueToList(int); // Adds a node to the list
	void linkListTraverse(); //Displays the list by traversing through each node
	int size(); // calculates the current length of the list
	void pairOfFour(); // Question 1
	void reverse(); // Question 2
	void shuffle(); // Question 3
	void clearList(); // Deletes the list after every test case execution
	void DisplayListInParts(); // Displays list in parts of 2, used for Question 3
};
#endif // !DOUBLELIST_H
