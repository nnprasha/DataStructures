#ifndef DOUBLENODE_H
#define DOUBLENODE_H
//The above statements act as a guard to avoid including this header file again and again

class DoubleNode {
public:
	int value; // data to be stored in the node
	DoubleNode *next; // pointer to the next node in the linked list
	DoubleNode *prev; //pointer to the previous node in the linked list
	DoubleNode(); //default constructor
};
#endif // !DOUBLENODE_H
