#ifndef SINGLENODE_H
#define SINGLENODE_H
//The above statements act as a guard to avoid including this header file again and again

//class SingleNode that defines a node
class SingleNode {
public:
	int value; // defines the data the node contains
	SingleNode *next; // pointer to the next node in the linked list
	SingleNode(); //default constructor		
};


#endif // !SINGLENODE_H
