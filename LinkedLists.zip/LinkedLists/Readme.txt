======================================================================================================
								README.TXT
======================================================================================================

3 programs on single linked lists and Doubly linked lists. 
1) Sort a linked list in a pair of 4. eg. Input: 2->3->1->4->5->0->2->1->. Output: 1->2->3->4->0->1->2->5
2) Reverse a linked list. Input: 1->2->3->4. output: 4->3->2->1
3) Shuffle a linked list. Input:1->2->3->4->5->6->7->8. output: 1->5->2->6->3->7->4->8.

--------------------------------------------------------------------------------------------

To Implement the linked list operations, I have used 3 .cpp files and 4 .h files
-> main.cpp
	This file includes the main function of the program. In the main function, I have defined the 12 different test cases to execute. 
	The main method calls all the other linked list functions to execute different test cases.
	It also calls a function to add nodes to th link lists. Thus, the input is provided inside the main function. 	
	rand() is used to generate random numbers for input. srand() is also used so that new set of random nubers are generated each time the program executes.
	Header files used - 
		<iostream> - for cout/cin i.e input/output
		SingleList.h , DoubleList.h
		time.h- for srand()
				-------------------------------------------------------------------------------------------------------				
->SingleNode.cpp
	This is an implementation file that defines all the functions of the SingleList class as well as the constructor of both SingleNode and SingleList class. 
	SingleNode::SingleNode()-> defines the constructor of the SingleNode class, initial next=NULL and value=0.
	//
	SingleList::SingleList()-> defines the constructor of the SingleList class, initializing the list head i.e head to NULL.
	//
	void SingleList::appendValueToList(int data)-> This function is used to add a new node to the list.It takes in a single parameter "data" that has 
	the data to be added to the list. This function is called repeatedly from the main to add nodes to the list.  
	//
	void SingleList::clearList()-> This function is used to delete the entire list. It is called after execution of every test case, so that a new 
	list is created for every new test case. Called from the main itself. 
	//
	void SingleList::linkListTraverse()-> This function is used to display the entire list by traversing through all the nodes from the begining and displaying
	each nodes value. Called from the main for each test case execution result to be shown.
	//
	void SingleList::DisplayListInParts()-> This function is used to display the list in parts i.e the first half and the second half. This function is used 
	during shuffling of the list (Question 3) to display the first and second halves of the list before the shuffle operation. Called from the main. 
	//
	int SingleList::size()->This function calculates the current length of the linked list. Called from various functions. 
	//
	**void SingleList::pairOfFour()-> This function demonstrates Question 1 i.e pair of four for a list. **Block A and Block B code have been defined
	inside this function, which is explained in the further sections. 
	//
	**void SingleList::reverse()-> This function demonstrates Question 2 i.e Reverse a list. **Block C code has been defined
	inside this function, which is explained in the further sections. 
	//
	**void SingleList::shuffle()-> This function demonstrates Question 3 i.e Shuffle a  list. **Block D and Block E code have been defined
	inside this function, which is explained in the further sections. 
				--------------------------------------------------------------------------------------------------------------
->DoubleNode.cpp
	This is an implementation file that defines all the functions of the DoubleList class as well as the constructor of both DoubleNode and DoubleList class. 
	DoubleNode::DoubleNode()-> defines the constructor of the DoubleNode class, initialises next & prev (Pointers to DoubleNode) to NULL and value=0.
	//
	DoubleList::DoubleList()-> defines the constructor of the DoubleList class, initializing the list head i.e head to NULL.
	//
	void DoubleList::appendValueToList(int data)-> This function is used to add a new node to the list.It takes in a single parameter "data" that has 
	the data to be added to the list. This function is called repeatedly from the main to add nodes to the list.  
	//
	void DoubleList::clearList()-> This function is used to delete the entire list. It is called after execution of every test case, so that a new 
	list is created for every new test case. Called from the main itself. 
	//
	void DoubleList::linkListTraverse()-> This function is used to display the entire list by traversing through all the nodes from the begining and displaying
	each nodes value. Called from the main for each test case execution result to be shown.
	//
	void DoubleList::DisplayListInParts()-> This function is used to display the list in parts i.e the first half and the second half. This function is used 
	during shuffling of the list (Question 3) to display the first and second halves of the list before the shuffle operation. Called from the main. 
	//
	int DoubleList::size()->This function calculates the current length of the linked list. Called from various functions. 
	//
	**void DoubleList::pairOfFour()-> This function demonstrates Question 1 i.e pair of four for a list. **Block F and Block G code have been defined
	inside this function, which is explained in the further sections. 
	//
	**void SingleList::reverse()-> This function demonstrates Question 2 i.e Reverse a list. **Block H code has been defined
	inside this function, which is explained in the further sections. 
	//
	**void SingleList::shuffle()-> This function demonstrates Question 3 i.e Shuffle a list. **Block I code have been defined
	inside this function, which is explained in the further sections. 
			------------------------------------------------------------------------------------------------------------
->SingleNode.h
	Defines the SingleNode class. 
			------------------------------------------------------------------------------------------------------------
->SingleList.h
	Defines the SingleList Class. includes "SingleNode.h" to use the functions declared in the SingleNode class. 
			------------------------------------------------------------------------------------------------------------
->DoubleNode.h
	Defines the DoubleNode class. 
			------------------------------------------------------------------------------------------------------------
->DoubleList.h
	Defines the DoubleList Class. includes "DoubleNode.h" to use the functions declared in the DoubleNode class. 
	
	=======================================================================================================================================================
	---------------------------------------Explanation of codes in BLOCKS marked by comments in code.----------------------------------------------------
	
1) BLOCK A- (used in Question 1 i.e pair of 4 for SINGLY LINK LIST)
	->This block of code is basically trying to sort the list in ascending order in a pair of four. 
	->3 loops have been used. The outer loop runs sizeoflist/4 times i.e if the size of the list is 12, the outermost loop will run 4 times. 
	  This logic is applied so that the list is sorted for every concurrent pair of four nodes found in the list. 
	->The inner 2 loops have been used to sort the list in ascending order by taking concurrent pair of four nodes. Bubble sort has been used i.e the largest
		element is sent to the last in the first iteration. 
	->Inside the IF statement of the inner most loop, the specific swapping takes place to sort the elements. 
	
2) BLOCK B- (used in Question 1 i.e pair of 4 for SINGLY LINKED LIST)
	->This block is used to sort the last group of elements in the list that cannot be paired into a group of four. For eg. if the list size is 15, then 
		the first 12 nodes will be sorted using block A and the last 3 will be sorted using block B. 

3)	BLOCK C- (used in Question 2 i.e Reverse a list for SINGLY LINKED LIST)
	->This block of code is used to reverese a list by adjusting the pointers of the list so that by the end of the while loop, the list is reversed. 
	->The while loop runs till the time current node hasnt reached NULL, and within the loop, the pointers are exchanged and the list is reversed. 
	
4) BLOCK D- (used in Question 3 i.e Shuffle for SINGLY LINKED LIST)
	->This block of code specifies the count to the first element of the second half of the list. 
	->If the length of the list is even, then size/2 will be the first element of the second half. But if the list is odd, size/2 +1 will be the 
		first element of the second half.
		
5) BLOCK E- (used in Question 3 i.e Shuffle for SINGLY LINKED LIST)
	->This block of code is used to shuffle a singly link list.
	->The pointers are set that points to the first half of the list and the second half. 
	->Respective node swapping takes place to shuffle the list. 

6) BLOCK F- (used in Question 1 i.e pair of 4 for DOUBLY LINKED LIST)
	->Same as BLOCK A, but here sorting has taken place for a doubly linked list.
	->When nodes are being swapped, not only the next pointer is being modified but also the prev pointer. 
	
7) BLOCK G- (used in Quesion 1 i.e pair of 4 for DOUBLY LINKED LIST)
	->Same as BLOCK B, but sorting is taking place for odubly linked list. 
	-> The prev pointer is also being modified. 
	
8) BLOCK H- (used in Question 2 i.e Reverse for DOUBLY LINK LIST)
	->Same as BLOCK C ,but for a doubly link list. 
	-> No need to use a seperate previous pointer that points to the previous node. As it is a doubly link list, prev and next pointers are modified to reverse
		the list.
9) BLOCK I- (used in Question 3 i.e Shuffle for DOUBLY LINK LIST)
	-> Same as BLOCK E, but for a doubly link list. 
	-> Pointers are set to the first and second half of the list , and respective swapping takes place, but here even the prev link is  
		modified as it is a DOUBLY LIST. 
	