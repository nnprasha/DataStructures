#include "Graph.h"
#include <sstream>
#include <iomanip>
#include <fstream>
#include <iostream>
#include <stdio.h>
#include <tr1/unordered_map>

using namespace std;

Graph::Graph()
{
	num_of_vertices = 0;
	num_of_edges = 0;
}

Graph::Graph(string csvFileName,vector<string> listofv,bool d)
{
	isUndirected = d;
	vertexList = listofv;
	int v1 = -1;
	int v2 = -1;
	ifstream myGraph(csvFileName.c_str());
	bool firstLine = true;
	if (myGraph.is_open())
	{
		while (myGraph.good())
		{
			string csvFileData;
			getline(myGraph, csvFileData);
			if (!firstLine)
			{
				v1++;
				v2 = -1;
				stringstream csvDataInString(csvFileData);
				for (size_t length = 0; length < csvFileData.size(); length++)
				{
					string val;
					getline(csvDataInString, val, ',');
					if (length != 0)
					{
						v2++;
						const char* c = val.c_str();
						int weightOfEdge = atoi(c);
						if (weightOfEdge > 0)
						{
							AddEdgeToGraph(v1, v2, weightOfEdge);
						}
					}
					
				}
			}
			firstLine = false;
		}
	}
	else
	{
		cout<<"Cannot open file";
	}
	
}

void Graph::AddEdgeToGraph(int vertexIndex1, int vertexIndex2, int w8)
{

	bool flag = true;
	AddVertexToGraph(vertexList.at(vertexIndex1));
	AddVertexToGraph(vertexList.at(vertexIndex2));

	Node* node = GetNode(vertexList.at(vertexIndex1));
	while (node->next != NULL)
	{
		if (node->next->data == vertexList.at(vertexIndex2))
		{
			flag = false;
			break;
		}
		else
			node = node->next;
	}
	if (flag)
	{
		node->next = new Node(vertexList.at(vertexIndex2), w8);
		num_of_edges++;
	}
	flag = true;
	if (isUndirected)
	{
		Node* node = GetNode(vertexList.at(vertexIndex2));
		while (node->next != NULL)
		{
			if (node->next->data == vertexList.at(vertexIndex1))
			{
				flag = false;
				break;
			}
			else
				node = node->next;
		}
		if (flag)
		{
			node->next = new Node(vertexList.at(vertexIndex1), w8);
			num_of_edges++;
		}
	}
}

void Graph::AddVertexToGraph(string node)
{
	if (!VertexSearch(node))
	{
		Node* newV = new Node(node);
		ajdList.push_back(newV);
		num_of_vertices++;
	}
}
//This function searched whether a vertex is present in the graph or not
bool Graph::VertexSearch(string key)
{
	for (vector<Node*>::iterator itr = ajdList.begin(); itr != ajdList.end(); itr++)
		if ((*itr)->data == key)
			return true;
	return false;
}

//This function will return a vertex if found in the graph
Node* Graph::GetNode(string key)
{
	for (vector<Node*>::iterator itr = ajdList.begin(); itr != ajdList.end(); itr++)
		if ((*itr)->data == key)
			return *itr;
	return NULL;
}

//This function will remove a vertex from the graph
void Graph::VertexRemoval(string v1)
{
	int index;
	for (int i = 0; i < ajdList.size(); i++)
	{
		if (ajdList.at(i)->data == v1)
		{
			index = i;
			break;
		}
	}
	Node* node = ajdList.at(index);
	while (node->next != NULL)
	{
		EdgeRemoval(node->data, node->next->data);
	}

	//This will remove the vertex from the adjacency list
	for (vector<Node*>::iterator itr = ajdList.begin(); itr != ajdList.end(); itr++)
	{
		if ((*itr)->data == v1)
		{
			ajdList.erase(itr);
			break;
		}
	}

	//For directed graph
	if (!isUndirected)
	{
		for (int i = 0; i < ajdList.size(); i++)
		{
			Node* node2 = GetNode(ajdList.at(i)->data);
			Node* tempNode = NULL;
			Node* prev = node2;
			tempNode = node2->next;
			while (tempNode != NULL)
			{
				if (tempNode->data == v1)
				{
					if (tempNode->next == NULL)
					{
						prev->next = NULL;
						num_of_edges--;
					}
					else
					{
						prev->next = tempNode->next;
						num_of_edges--;
						break;
					}
				}
				prev = tempNode;
				tempNode = tempNode->next;
			}
		}
	}	

	//This will remove the vertex from the list of vertices (Vertex List)
	for (vector<string>::iterator itr = vertexList.begin(); itr != vertexList.end(); itr++)
	{
		if (*itr == v1)
		{
			vertexList.erase(itr);
			break;
		}
	}

}

//This function will remove the edge (v1,v2)
void Graph::EdgeRemoval(string v1, string v2)
{
	if (GetNode(v1) != NULL && GetNode(v2) != NULL)
	{
		Node* node1 = GetNode(v1);
		Node* tempNode = NULL;
		Node* prev = node1;
		tempNode = node1->next;
		while (tempNode != NULL)
		{
			if (tempNode->data == v2)
			{
				if (tempNode->next == NULL)
				{
					prev->next = NULL;
					num_of_edges--;
				}
				else
				{
					prev->next = tempNode->next;
					num_of_edges--;
					break;
				}
			}
			prev = tempNode;
			tempNode = tempNode->next;
		}

		if (isUndirected)
		{
			Node* node2 = GetNode(v2);
			Node* tempNode2 = NULL;
			Node* prev = node2;
			tempNode2 = node2->next;
			while (tempNode2 != NULL)
			{
				if (tempNode2->data == v1)
				{
					if (tempNode2->next == NULL)
					{
						prev->next = NULL;
						num_of_edges--;
					}
					else
					{
						prev->next = tempNode2->next;
						num_of_edges--;
						break;
					}
				}
				prev = tempNode2;
				tempNode2 = tempNode2->next;
			}
		}
	}
}

//This function would find the shortes path to all other vertices from source vertec src
void Graph::FindShortestPath_Dijkstra(string src)
{
	GraphInitialization();
	string src1 = src;
	Node* node = GetNode(src1);
	node->distance = 0;
	for (int i = 0; i < num_of_vertices; i++)
	{
		Node* node2 = GetNode(src);
		node2->over = true;
		Node* tempNode = node2->next;
		while (tempNode != NULL)
		{
			if (!GetNode(tempNode->data)->over)
				GraphRelax(node2, tempNode);
			tempNode = tempNode->next;
		}
		node2 = FindMinNode();
		if (node2 != NULL)
			src = node2->data;
		else
			break;
	}
}

//This function initializes the graph
void Graph::GraphInitialization()
{
	for (vector<Node*>::iterator itr = ajdList.begin(); itr != ajdList.end(); itr++)
	{
		(*itr)->distance = 999; //Infinity
		(*itr)->pre = NULL;
		(*itr)->over = false;
		Node* tempNode = (*itr)->next;
		while (tempNode != NULL)
		{
			tempNode->distance = 999;
			tempNode->over = false;
			tempNode->pre = NULL;
			tempNode = tempNode->next;
		}
	}
}

//This function finds the minimum node distance
Node* Graph::FindMinNode()
{
	int minimum = 999;
	Node* node = NULL;
	for (std::vector<Node*>::iterator itr = ajdList.begin(); itr != ajdList.end(); itr++)
	{
		if ((*itr)->distance < minimum && (*itr)->over == false)
		{
			minimum = (*itr)->distance;
			node = GetNode((*itr)->data);
		}

	}
	return node;
}

//This function would return the weight between node1 and node2
int Graph::weightRetrieval(Node* node1, Node* node2)
{
	Node* itr = GetNode(node1->data);
	Node* tempNode = itr->next;
	while (tempNode != NULL)
	{
		if (tempNode->data == node2->data)
		{
			return tempNode->weight;
		}
		tempNode = tempNode->next;
	}
	return 999;
}

//This function would update all values of the graph
void Graph::GraphRelax(Node* node1, Node* node2)
{
	int weight = weightRetrieval(node1, node2);
	if (node2->distance > (node1->distance + weight))
	{
		GraphUpdate(node2->data, (node1->distance + weight), node1);
	}
}

//Updates the graph references
void Graph::GraphUpdate(string node, int new_distance, Node* new_pre)
{
	for (vector<Node*>::iterator itr = ajdList.begin(); itr != ajdList.end(); itr++)
	{
		if ((*itr)->data == node)
		{
			(*itr)->distance = new_distance;
			(*itr)->pre = new_pre;
		}
		Node* tempNode = (*itr)->next;
		while (tempNode != NULL)
		{
			if (tempNode->data == node)
			{
				tempNode->distance = new_distance;
				tempNode->pre = new_pre;
			}
			tempNode = tempNode->next;
		}
	}
}
//Display shortest displace from src vertex
void Graph::ShortestDistanceDisplay(int nofvertices, string src)
{
	cout << src;
	Node* node = GetNode(src);
	for (vector<Node*>::iterator itr = ajdList.begin(); itr != ajdList.end(); itr++)
	{
		if ((*itr)->data != src)
		{
			vector<string> shortestPath;
			int weight = 0;

			shortestPath.push_back((*itr)->data);

			if ((*itr)->pre != NULL)
			{
				shortestPath.push_back(((*itr)->pre)->data);
				weight += weightRetrieval((*itr)->pre, (*itr));
				Node* y = (*itr)->pre;
				while (y->data != src)
				{
					shortestPath.push_back((y->pre)->data);
					weight += weightRetrieval(y->pre, y);
					y = y->pre;
				}
			}
			if (weight > 0)
			{
				cout << "\t" << weight;
			}
			while (shortestPath.size() > 0)
			{
				shortestPath.erase(shortestPath.end() - 1);
			}

		}
		else {
			cout << "\t" << "0";
		}
	}
	
	std::cout << "\n";
}

//Shortest Path Display
void Graph::ShortestPathDisplay(int nofvertices, string src)
{	
	Node* node = GetNode(src);
	int i = 1;
	for (std::vector<Node*>::iterator itr = ajdList.begin(); itr != ajdList.end(); itr++)
	{
		if (i <= nofvertices)
		{
			if ((*itr)->data != src)
			{
				vector<string> shortestPath;
				int weight = 0;

				shortestPath.push_back((*itr)->data);

				if ((*itr)->pre != NULL)
				{
					shortestPath.push_back(((*itr)->pre)->data);
					weight += weightRetrieval((*itr)->pre, (*itr));
					Node* y = (*itr)->pre;
					while (y->data != src)
					{
						shortestPath.push_back((y->pre)->data);
						weight += weightRetrieval(y->pre, y);
						y = y->pre;
					}
				}
				if (shortestPath.size() > 1)
				{
					cout << "\n\t" << (*itr)->data << " \t\t";
					i++;
				}
				while (shortestPath.size() > 0)
				{
					cout << shortestPath.back() << " ";
					shortestPath.erase(shortestPath.end() - 1);
				}
			}
			else
			{
				cout << "\n\t" << (*itr)->data << " \t\t"<<"nil";
			}
		}
	}
	cout << "\n";
}

//This function returns a map of shortest paths from src to dest
std::tr1::unordered_map<string, string> Graph::ShortestPathRetrieval(string dest, string src)
{
	std::tr1::unordered_map<string, string> pathEdges;
	Node* node = GetNode(src);
	string i;
	int c = 0;
	for (std::vector<Node*>::iterator itr = ajdList.begin(); itr != ajdList.end(); itr++)
	{
		i = vertexList.at(c);
		if (i == dest)
		{
			if ((*itr)->data != src)
			{
				std::vector<string> shortestPath;
				shortestPath.push_back((*itr)->data);
				if ((*itr)->pre != NULL)
				{
					shortestPath.push_back(((*itr)->pre)->data);
					Node* y = (*itr)->pre;
					while (y->data != src)
					{
						shortestPath.push_back((y->pre)->data);
						y = y->pre;
					}
				}
				while (shortestPath.size() > 0)
				{
					string ed1 = shortestPath.back();
					shortestPath.erase(shortestPath.end() - 1);
					if (shortestPath.size() > 0)
					{
						string ed2 = shortestPath.back();
						pathEdges.insert({ ed1, ed2 });
					}
				}
			}
		}
		c++;
	}
	return pathEdges;
}

//Dot file Creation
void Graph::CreateDotFile(Graph* g, FILE* f, bool flag)
{
	if (g->isUndirected)
	{
		fprintf(f, "strict graph {\n");
	}		
	else
	{
		fprintf(f, "digraph BST {\n");
	}
		
	fprintf(f, "    node [fontname=\"Arial\"];\n");
	vector<Node*> tempAdjList = g->ajdList;
	if (tempAdjList.size() == 0)
	{
		fprintf(f, "\n");
	}		
	else
	{
		for (vector<Node*>::iterator itr = tempAdjList.begin(); itr != tempAdjList.end(); itr++)
		{
			Node* tempNode = (*itr)->next;
			if (tempNode != NULL)
			{
				while (tempNode != NULL)
				{
					if (g->isUndirected)
					{
						ostringstream convert;
						convert << (*itr)->data;
						string s = convert.str();

						convert.str("");
						convert << tempNode->data;
						string k = convert.str();						
							fprintf(f, "    \"%s\" -- \"%s\";\n", s.c_str(), k.c_str());
					}						
					else
					{
						ostringstream convert;
						convert << (*itr)->data;
						string s = convert.str();

						convert.str("");
						convert << tempNode->data;
						string k = convert.str();
						int w8 = weightRetrieval((*itr), tempNode);
						convert.str("");
						convert << w8;
						string weight = convert.str();
						if (w8 > -1 && flag)
							fprintf(f, "    \"%s\" -> \"%s\"[label=\"%s\"];\n", s.c_str(),k.c_str(),weight.c_str());
						else
							fprintf(f, "    \"%s\" -> \"%s\";\n", s.c_str(), k.c_str());
					}						
					tempNode = tempNode->next;
				}
			}
			else
			{
				ostringstream convert;
				convert << (*itr)->data;
				string s = convert.str();
				fprintf(f, "    \"%s\";\n", s.c_str());
			}				
		}
	}
	fprintf(f, "}\n");
}

//create a dot file for graph along with colored edges which are part of shortest path
void Graph::CreateColoredDotFile(Graph* g, FILE* f,std::tr1::unordered_map<string, string> pathEdges,string color1)
{
	if (g->isUndirected)
		fprintf(f, "strict graph {\n");
	else
		fprintf(f, "digraph BST {\n");
	fprintf(f, "    node [fontname=\"Arial\"];\n");
	vector<Node*> tempAdjList = g->ajdList;
	if (tempAdjList.size() == 0)
		fprintf(f, "\n");
	else
	{
		for (vector<Node*>::iterator itr = tempAdjList.begin(); itr != tempAdjList.end(); itr++)
		{
			Node* tempNode = (*itr)->next;
			if (tempNode != NULL)
			{
				while (tempNode != NULL)
				{
					string d1 = (*itr)->data;
					string d2 = tempNode->data;
					std::tr1::unordered_map<string, string>::iterator itr2;
					bool color = false;
					itr2 = pathEdges.find(d1);
					if (itr2 != pathEdges.end())
					{
						if (itr2->second == d2)
							color = true;
					}
					if (g->isUndirected)
					{
						int w8 = weightRetrieval((*itr), tempNode);
						ostringstream convert;
						convert << w8;
						string weight = convert.str();
						if (color)
							fprintf(f, "    \"%s\" -- \"%s\"[color=\"%s\",label=\"%s\"];\n", (*itr)->data.c_str(), tempNode->data.c_str(),color1.c_str(),weight.c_str());
						else
							fprintf(f, "    \"%s\" -- \"%s\"[label=\"%s\"];\n", (*itr)->data.c_str(), tempNode->data.c_str(),weight.c_str());
					}
					else
					{
						int w8 = weightRetrieval((*itr), tempNode);
						ostringstream convert;
						convert << w8;
						string weight = convert.str();
						if (color)
							fprintf(f, "    \"%s\" -> \"%s\"[color=\"%s\",label=\"%s\"];\n", (*itr)->data.c_str(), tempNode->data.c_str(),color1.c_str(),weight.c_str());
						else
							fprintf(f, "    \"%s\" -> \"%s\"[label=\"%s\"];\n", (*itr)->data.c_str(), tempNode->data.c_str(),weight.c_str());
					}
					tempNode = tempNode->next;
				}
			}
			else
				fprintf(f, "    \"%s\";\n", (*itr)->data.c_str());
		}
	}
	fprintf(f, "}\n");
}
