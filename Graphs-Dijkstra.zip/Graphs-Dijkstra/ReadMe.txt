======================================================================================================
								README.TXT
======================================================================================================
Implementations on Graph data structures and Dijkstra shortest path algorithm
-------------------------------------------------------------------------------------
**NOTE**-> Please compile by using this command : "g++ -o output *.cpp -std=c++11" to avoid warnings. 


To Implement all the operations specified in the assignment, I have used 3 .cpp files and 2 .h files.
-> main.cpp
	This file includes the main function of the program. In the main function, I have defined the 12 different test cases to execute. 
		
	All the input is provided inside the main function. 	
	rand() is used to generate random numbers for input. srand() is also used so that new set of random nubers are generated each time the program executes.
	Header files used - 
		<iostream> - for cout/cin i.e input/output
		time.h- for srand()
		sstream for ostringstream
		
	2 other methods have been defined in the main class
	makeVectorList --- > which retrives text from csv file and adds nodes to a vectorList
	uniqueRandomNumers ----> Generated unique random numbers
				-------------------------------------------------------------------------------------------------------				
->BST.cpp
	Graph(string,vector<string>,bool); //Constructor that takes in a file input and constructs a graph
	void AddEdgeToGraph(int,int,int);	//Adds an edge to the graph
	void AddVertexToGraph(string);	//Adds an vertex to the graph
	bool Graph::VertexSearch(string);	//Searches for a specified vertex in the graph
	Node* GetNode(string);	// Retrieves a vertex from the graph
	void EdgeRemoval(string, string);	//Deletes an edge from the graph
	void VertexRemoval(string);	//deleles a vertex and all its associated edges from the graph
	void CreateDotFile(Graph*, FILE*);	//Creates a dot file
	void Graph::FindShortestPath_Dijkstra(string);	//Finds shortes path
	int weightRetrieval(Node*, Node*);	//Returns the weight betwwen 2 vertices
	void GraphRelax(Node*, Node*);	//Updates the graph
	void GraphUpdate(string, int, Node*);	//Updates the graph references
	Node* FindMinNode();	//Finds minimum node distance in graph
	void GraphInitialization();	//Initialzes the graph
	void ShortestDistanceDisplay(int, string);	//Displays shortes distance to all nodes from src vertes
	void ShortestPathDisplay(int,string);	//DIsplayst the shortes path
	unordered_map<string,string> ShortestPathRetrieval(string, string); //Returns a map of edges specifying a path from src to desst
	void CreateColoredDotFile(Graph*, FILE*, unordered_map<string, string>,string);	//Creates colored dot files for Test case 11 and 12
	
	
	------------------------------------------------------------------------------------------------------------

	--------------------------------------------------------------------------------------------------------------------
References: 
	Web: 
	--> http://eli.thegreenplace.net/2009/11/23/visualizing-binary-trees-with-graphviz
	--> http://geeksforgeeks.com
	--> http://stackoverflow.com
	
	Class Texts:
	--> Data Structures and Algorithms in c++ by Adam Drozdek
	--> CLRS-Introduction to algorithms-3rd edition
	
	=======================================================================================================================================================
