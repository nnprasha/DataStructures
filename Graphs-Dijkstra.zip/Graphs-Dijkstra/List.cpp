
#include "List.h"
#include <string>
using namespace std;

Node::Node()
{
	data = "";
	next = NULL;
	weight = 0;
	distance = 999;
	pre = NULL;
	over = false;
}

Node::Node(string value)
{
	data = value;
	next = NULL;
	weight = 0;
	distance = 999;
	pre = NULL;
	over = false;
}

Node::Node(string value, int w8)
{
	data = value;
	next = NULL;
	weight = w8;
	distance = 999;
	pre = NULL;
	over = false;
}

List::List()
{	
	head = NULL;
	length_of_list = 0;
}


