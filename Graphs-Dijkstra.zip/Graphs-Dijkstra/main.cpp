// ADS-Assignment4.cpp : Defines the entry point for the console application.
//

#include "Graph.h"
#include <stdio.h>
#include <fstream>
#include <sstream>
#include <iostream>
#include <time.h>
#include <tr1/unordered_map>

vector<int> randomNumbers;

//Makes a list of vectors
vector<string> makeVectorList(string fileName)
{
	ifstream myGraph(fileName.c_str());
	vector<string> listofv;
	if (myGraph.is_open())
	{
		string csvFileData;
		getline(myGraph, csvFileData, '\n');
		stringstream csvDataInString(csvFileData);
		for (size_t length = 0; length < csvFileData.size(); length++)
		{
			string val;
			getline(csvDataInString, val, ',');
			if (length != 0)
			{
				if (val != "")
					listofv.push_back(val);
			}

		}
	}
	return listofv;
}

//Generates unique random numbers
int uniqueRandomNumber(int range)
{
	int flag = true;
	int key = 0;
	while (flag)
	{
		flag = false;
		key = rand() % range;
		for (int i = 0; i < randomNumbers.size(); i++)
		{
			if (key == randomNumbers.at(i))
			{
				flag = true;
				break;
			}
		}
	}
	randomNumbers.push_back(key);
	return key;
}

int main()
{
	srand(time(NULL));
	cout << "\n===============================================================================\n";
	cout << "\t\t TEST CASE 1 (UNDIRECTED, UNWEIGHTED)";
	cout << "\n===============================================================================\n";

	
	vector<string> listofv1 = makeVectorList("fig1.csv");
	cout << "Creating undirected unweighted graph G1 by passing fig1.csv to the constructor...\n";
	Graph g1("fig1.csv",listofv1,true); //filename passed

	cout << "Creating dot file t1.dot for the constructed graph..\n";

	string file1 = "t1.dot";
	FILE* t1 = fopen(file1.c_str(),"w");

	g1.CreateDotFile(&g1, t1, false);
	cout << "dot file t1.dot created";
	cout << endl;

	
	cout << "\n===============================================================================\n";
	cout << "\t\t TEST CASE 2 (DIRECTED, UNWEIGHTED)";
	cout << "\n===============================================================================\n";

	cout << "Creating directed unweighted graph G2 by passing fig2.csv to the constructor...\n";
	vector<string> listofv2 = makeVectorList("fig2.csv");
	Graph g2("fig2.csv",listofv2,false);
	//g2.isUndirected = false; //Graph is directed

	cout << "creating dot file t2.dot for the constructed graph..\n";
	string file2 = "t2.dot";
	FILE *t2 = fopen(file2.c_str(),"w");

	g2.CreateDotFile(&g2, t2, false);
	cout << "dot file t2.dot created";
	cout << endl;
	
	
	cout << "\n===============================================================================\n";
	cout << "\t\t TEST CASE 3 (DIRECTED, WEIGHTED)";
	cout << "\n===============================================================================\n";

	cout << "Creating directed weighted graph G3 by passing fig3-w.csv to the constructor...\n";
	vector<string> listofv3 = makeVectorList("fig3-w.csv");
	Graph g3("fig3-w.csv",listofv3,false);
	g3.isUndirected = false; //Graph is directed weighted
	
	string file3 = "t3.dot";
	FILE *t3 = fopen(file3.c_str(),"w");

	cout << "creating dot file t3.dot for the constructed graph..\n";
	g3.CreateDotFile(&g3, t3, true);
	cout << "dot file t3.dot created";
	cout << endl;
	
	cout << "\n===============================================================================\n";
	cout << "\t\t TEST CASE 4";
	cout << "\n===============================================================================\n";

	cout << "Vertex z inserted to Graph G1...\n";
	g1.isUndirected = true;
	g1.vertexList.push_back("z");
	g1.AddVertexToGraph("z"); //Adding vertex z to graph

	int w, x, y;
	for (int i = 0; i < g1.vertexList.size(); i++)
	{
		if (g1.vertexList.at(i) == "w")
			w = i;
		else if (g1.vertexList.at(i) == "x")
			x = i;
		else if (g1.vertexList.at(i) == "y")
			y = i;
	}
	cout << "Adding edges (z,w) (z,x) (z,y) to grapg G1..\n";
	g1.AddEdgeToGraph(g1.vertexList.size()-1, w, 1); //adding (z,w)
	g1.AddEdgeToGraph(g1.vertexList.size()-1, x, 1); //adding (z,x)
	g1.AddEdgeToGraph(g1.vertexList.size()-1, y, 1); //adding (z,y)

	cout << "dot file t4a.dot created!!\n";
	string file4a = "t4a.dot";
	FILE *t4a = fopen(file4a.c_str(),"w");

	g1.CreateDotFile(&g1, t4a, false);	//Creaing t4a.dot

	cout << "Removing vertices s and then x\n";
	g1.VertexRemoval("s");
	g1.VertexRemoval("x");

	cout << "Removing edge (u,t)\n";
	g1.EdgeRemoval("u", "t");

	cout << "dot file t4b.dot Created\n";

	string file4b = "t4b.dot";
	FILE *t4b = fopen(file4b.c_str(),"w");

	g1.CreateDotFile(&g1, t4b, false);
	cout << endl;

	cout << "\n===============================================================================\n";
	cout << "\t\t TEST CASE 5";
	cout << "\n===============================================================================\n";

	Graph g5;
	g5.isUndirected = true;

	cout << "Inserting vertices 6...10 to graph G5\n";
	g5.vertexList.push_back("6"); //0
	g5.vertexList.push_back("7");	//1
	g5.vertexList.push_back("8");	//2
	g5.vertexList.push_back("9");	//3
	g5.vertexList.push_back("10");	//4

	g5.AddVertexToGraph("6");
	g5.AddVertexToGraph("7");	
	g5.AddVertexToGraph("8");
	g5.AddVertexToGraph("9");
	g5.AddVertexToGraph("10");


	cout << "Inserting edges (6,7),(7,8),(8,9),(9,10),(10,6)\n";
	
	g5.AddEdgeToGraph(0, 1, 1);
	g5.AddEdgeToGraph(1, 2, 1);
	g5.AddEdgeToGraph(2, 3, 1);
	g5.AddEdgeToGraph(3, 4, 1);
	g5.AddEdgeToGraph(4, 0, 1);

	cout << "Inserting vertices 1...5\n";

	g5.vertexList.push_back("1");	// 5
	g5.vertexList.push_back("2");	// 6
	g5.vertexList.push_back("3");	// 7
	g5.vertexList.push_back("4");	// 8
	g5.vertexList.push_back("5");	// 9

	g5.AddVertexToGraph("1");
	g5.AddVertexToGraph("2");
	g5.AddVertexToGraph("3");
	g5.AddVertexToGraph("4");
	g5.AddVertexToGraph("5");

	cout << "Inserting Edges (1,6), (2,7), (3,8), (4,9), (5,10) to graph G5\n";

	g5.AddEdgeToGraph(5, 0, 1);
	g5.AddEdgeToGraph(6, 1, 1);
	g5.AddEdgeToGraph(7, 2, 1);
	g5.AddEdgeToGraph(8, 3, 1);
	g5.AddEdgeToGraph(9, 4, 1);

	cout << "dot file t5a created!!\n";

	string file5a = "t5a.dot";
	FILE *t5a = fopen(file5a.c_str(),"w");

	g5.CreateDotFile(&g5, t5a, false);

	cout << "Removing vertex 8 followed by vertex 6\n";
	g5.VertexRemoval("8");
	g5.VertexRemoval("6");

	cout << "dot file t5b created!!\n";
	string file5b = "t5b.dot";
	FILE *t5b = fopen(file5b.c_str(),"w");

	g5.CreateDotFile(&g5, t5b, false);


	cout << "\n===============================================================================\n";
	cout << "\t\t TEST CASE 6";
	cout << "\n===============================================================================\n";
	randomNumbers.clear();
	string vertices1[5] = { "2", "4", "6", "8", "10" };
	string vertices2[5] = { "1","3","5","7","9" };
	Graph g6;
	g6.isUndirected = false;
	cout << " insert the vertices 2, 4, 6, 8, 10 in random order to Graph G6\n";

	int i = uniqueRandomNumber(5);
	g6.AddVertexToGraph(vertices1[i]);
	cout << "-->inserting " << vertices1[i]<<endl;
	g6.vertexList.push_back(vertices1[i]);

	i = uniqueRandomNumber(5);
	g6.AddVertexToGraph(vertices1[i]);
	cout << "-->inserting " << vertices1[i] << endl;
	g6.vertexList.push_back(vertices1[i]);

	i = uniqueRandomNumber(5);
	g6.AddVertexToGraph(vertices1[i]);
	cout << "-->inserting " << vertices1[i] << endl;
	g6.vertexList.push_back(vertices1[i]);

	i = uniqueRandomNumber(5);
	g6.AddVertexToGraph(vertices1[i]);
	cout << "-->inserting " << vertices1[i] << endl;
	g6.vertexList.push_back(vertices1[i]);

	i = uniqueRandomNumber(5);
	g6.AddVertexToGraph(vertices1[i]);
	cout << "-->inserting " << vertices1[i] << endl;
	g6.vertexList.push_back(vertices1[i]);

	randomNumbers.clear();

	cout << "\nInserting (2,4), (2,6), (4,6), (4,8), (6,8), (6,10), (8,10), (8,2) edges to Graph G6";
	int a, b, c, d, e;
	for (int j = 0; j < g6.vertexList.size(); j++)
	{
		if (g6.vertexList.at(j) == "2")
			a = j;
		else if (g6.vertexList.at(j) == "4")
			b = j;
		else if (g6.vertexList.at(j) == "6")
			c = j;
		else if (g6.vertexList.at(j) == "8")
			d = j;
		else if (g6.vertexList.at(j) == "10")
			e = j;
	}

	g6.AddEdgeToGraph(a, b, 1);
	g6.AddEdgeToGraph(a, c, 1);
	g6.AddEdgeToGraph(b, c, 1);
	g6.AddEdgeToGraph(b,d,1);
	g6.AddEdgeToGraph(c, d, 1);
	g6.AddEdgeToGraph(c, e, 1);
	g6.AddEdgeToGraph(d,e,1);
	g6.AddEdgeToGraph(d, a, 1);

	cout << "\n\nInserting vertices 1, 3, 5, 7, 9 in random order\n";

	int k = uniqueRandomNumber(5);
	g6.AddVertexToGraph(vertices2[k]);
	cout << "-->inserting " << vertices2[k] << endl;
	g6.vertexList.push_back(vertices2[k]);

	k = uniqueRandomNumber(5);
	g6.AddVertexToGraph(vertices2[k]);
	cout << "-->inserting " << vertices2[k] << endl;
	g6.vertexList.push_back(vertices2[k]);

	k = uniqueRandomNumber(5);
	g6.AddVertexToGraph(vertices2[k]);
	cout << "-->inserting " << vertices2[k] << endl;
	g6.vertexList.push_back(vertices2[k]);

	k = uniqueRandomNumber(5);
	g6.AddVertexToGraph(vertices2[k]);
	cout << "-->inserting " << vertices2[k] << endl;
	g6.vertexList.push_back(vertices2[k]);

	k = uniqueRandomNumber(5);
	g6.AddVertexToGraph(vertices2[k]);
	cout << "-->inserting " << vertices2[k] << endl;
	g6.vertexList.push_back(vertices2[k]);

	randomNumbers.clear();

	cout << "\n\nInserting (1,2), (3,4), (5,6), (7,8), (9,10) to Graph G6";
	int p, q, r, s, t;
	for (int j = 0; j < g6.vertexList.size(); j++)
	{
		if (g6.vertexList.at(j) == "1")
			p = j;
		else if (g6.vertexList.at(j) == "3")
			q = j;
		else if (g6.vertexList.at(j) == "5")
			r = j;
		else if (g6.vertexList.at(j) == "7")
			s = j;
		else if (g6.vertexList.at(j) == "9")
			t = j;
	}

	g6.AddEdgeToGraph(p, a, 1);
	g6.AddEdgeToGraph(q, b, 1);
	g6.AddEdgeToGraph(r, c, 1);
	g6.AddEdgeToGraph(s, d, 1);
	g6.AddEdgeToGraph(t, e, 1);

	cout << "\n\ndot file t6a.dot created!!";
	string file6a = "t6a.dot";
	FILE *t6a = fopen(file6a.c_str(),"w");

	g6.CreateDotFile(&g6, t6a, false);

	cout << "\nRandomly choosing a vertex from 2, 4, 6, 8, 10, removing it and all of its associated edges";
	int m = uniqueRandomNumber(5);
	cout << "\n-->Removing " << vertices1[m];
	g6.VertexRemoval(vertices1[m]);

	cout << "\n\nRandomly choosing a vertex from 1, 3, 5, 7, 9, removing it and all of its associated edges";
	int n = uniqueRandomNumber(5);
	cout << "\n-->Removing " << vertices2[n];
	g6.VertexRemoval(vertices2[n]);

	cout << "\n\ndot file t6b.dot created!!";
	string file6b = "t6b.dot";
	FILE *t6b = fopen(file6b.c_str(),"w");

	g6.CreateDotFile(&g6, t6b, false);


	cout << "\n===============================================================================\n";
	cout << "\t\t TEST CASE 7";
	cout << "\n===============================================================================\n";
	
	cout << "\n===============================================================================\n";
	cout << "\ts\tt\ty\tx\tz";
	cout << "\n===============================================================================\n";
	g3.FindShortestPath_Dijkstra("s"); 
	g3.ShortestDistanceDisplay(g3.num_of_vertices,"s");

	g3.FindShortestPath_Dijkstra("t");
	g3.ShortestDistanceDisplay(g3.num_of_vertices, "t");
	
	g3.FindShortestPath_Dijkstra("y");
	g3.ShortestDistanceDisplay(g3.num_of_vertices, "y");

	g3.FindShortestPath_Dijkstra("x");
	g3.ShortestDistanceDisplay(g3.num_of_vertices, "x");
	
	g3.FindShortestPath_Dijkstra("z");
	g3.ShortestDistanceDisplay(g3.num_of_vertices, "z");




	cout << "\n===============================================================================\n";
	cout << "\t\t TEST CASE 8";
	cout << "\n===============================================================================\n";

	cout << "\n===============================================================================\n";
	cout << "\ts\tt\ty\tx\tz";
	cout << "\n===============================================================================\n";
	
	vector<string> listofv8 = makeVectorList("fig3-w.csv");
	Graph g4("G4.csv", listofv8, true);
	g4.isUndirected = true; 

	g4.FindShortestPath_Dijkstra("s");
	g4.ShortestDistanceDisplay(g4.num_of_vertices, "s");

	g4.FindShortestPath_Dijkstra("t");
	g4.ShortestDistanceDisplay(g4.num_of_vertices, "t");

	g4.FindShortestPath_Dijkstra("y");
	g4.ShortestDistanceDisplay(g4.num_of_vertices, "y");

	g4.FindShortestPath_Dijkstra("x");
	g4.ShortestDistanceDisplay(g4.num_of_vertices, "x");

	g4.FindShortestPath_Dijkstra("z");
	g4.ShortestDistanceDisplay(g4.num_of_vertices, "z");

	cout << "\n===============================================================================\n";
	cout << "\t\t TEST CASE 9";
	cout << "\n===============================================================================\n";


	cout << "\n===============================================================================\n";
	std::cout << "     Vertex  \t Path from source vertex s to this vertex in G3";
	cout << "\n===============================================================================\n";
	g3.FindShortestPath_Dijkstra("s"); //Shortest path from s
	g3.ShortestPathDisplay(g3.num_of_vertices, "s");


	cout << "\n===============================================================================\n";
	std::cout << "     Vertex  \t Path from source vertex z to this vertex in G3";
	cout << "\n===============================================================================\n";
	g3.FindShortestPath_Dijkstra("z");	//Shortest path from z
	g3.ShortestPathDisplay(g3.num_of_vertices, "z");


	cout << "\n===============================================================================\n";
	cout << "\t\t TEST CASE 10";
	cout << "\n===============================================================================\n";


	cout << "\n===============================================================================\n";
	std::cout << "     Vertex  \t Path from source vertex s to this vertex in G4";
	cout << "\n===============================================================================\n";
	g4.FindShortestPath_Dijkstra("s");
	g4.ShortestPathDisplay(g4.num_of_vertices, "s");


	cout << "\n===============================================================================\n";
	std::cout << "     Vertex  \t Path from source vertex z to this vertex in G4";
	cout << "\n===============================================================================\n";
	g4.FindShortestPath_Dijkstra("z");
	g4.ShortestPathDisplay(g4.num_of_vertices, "z");

	cout << "\n===============================================================================\n";
	cout << "\t\t TEST CASE 11";
	cout << "\n===============================================================================\n";
	vector<std::tr1::unordered_map<string, string> > vectorOfShortestPaths;
	vector<int> pathCosts;
	for (int i = 0; i < g3.vertexList.size(); i++)
	{
		string src = g3.vertexList.at(i);
		for (int i = 0; i < g3.vertexList.size(); i++)
		{
			g3.FindShortestPath_Dijkstra(src);
			std::tr1::unordered_map<string, string> edge = g3.ShortestPathRetrieval(g3.vertexList.at(i), src);
			if (edge.size() != 0)
			{
				vectorOfShortestPaths.push_back(edge);
				int weight = 0;
				for (std::tr1::unordered_map<string, string>::iterator it = edge.begin(); it != edge.end(); it++)
				{
					weight=weight+g3.weightRetrieval(g3.GetNode(it->first), g3.GetNode(it->second));
				}
				pathCosts.push_back(weight);
			}				
		}
	}
	int max = pathCosts.at(0);
	int maxIndex = 0;
	for (int i = 0; i < pathCosts.size(); i++)
	{
		if (max < pathCosts.at(i))
		{
			maxIndex = i;
			max = pathCosts.at(i);
		}
			
	}

	std::tr1::unordered_map<string, string> p1 = vectorOfShortestPaths.at(maxIndex);
	int count = 0;
	cout << "\nPath P for graph G3 is found to be: ";
	for (std::tr1::unordered_map<string, string>::iterator it = p1.begin(); it != p1.end(); it++)
	{
		if (count == 0)
			cout << it->first << "->" << it->second;
		else
			cout << "->"<<it->second;
		count++;
	}
	
	cout << "\n\n dot file t11.dot created!!";
	string file11 = "t11.dot";
	FILE *t11 = fopen(file11.c_str(),"w");

	g3.CreateColoredDotFile(&g3, t11, p1,"red");



	cout << "\n===============================================================================\n";
	cout << "\t\t TEST CASE 12";
	cout << "\n===============================================================================\n";
	vector<std::tr1::unordered_map<string, string> > vectorOfShortestPaths2;
	vector<int> pathCosts2;
	for (int i = 0; i < g4.vertexList.size(); i++)
	{
		string src = g4.vertexList.at(i);
		for (int i = 0; i < g4.vertexList.size(); i++)
		{
			g4.FindShortestPath_Dijkstra(src);
			std::tr1::unordered_map<string, string> edge2 = g4.ShortestPathRetrieval(g4.vertexList.at(i), src);
			if (edge2.size() != 0)
			{
				vectorOfShortestPaths2.push_back(edge2);
				int weight = 0;
				for (std::tr1::unordered_map<string, string>::iterator it = edge2.begin(); it != edge2.end(); it++)
				{
					weight = weight + g4.weightRetrieval(g4.GetNode(it->first), g4.GetNode(it->second));
				}
				pathCosts2.push_back(weight);
			}
		}
	}
	int max2 = pathCosts2.at(0);
	int maxIndex2 = 0;
	for (int i = 0; i < pathCosts2.size(); i++)
	{
		if (max2 < pathCosts2.at(i))
		{
			maxIndex2 = i;
			max2 = pathCosts2.at(i);
		}

	}

	std::tr1::unordered_map<string, string> p2 = vectorOfShortestPaths2.at(maxIndex2);
	int count2 = 0;
	cout << "\nPath P for graph G4 is found to be: ";
	for (std::tr1::unordered_map<string, string>::iterator it = p2.begin(); it != p2.end(); it++)
	{
		if (count2 == 0)
			cout << it->first << "->" << it->second;
		else
			cout << "->" << it->second;
		count2++;
	}

	cout << "\n\n dot file t12.dot created!!";
	string file12 = "t12.dot";
	FILE *t12 = fopen(file12.c_str(),"w");

	g4.CreateColoredDotFile(&g4, t12, p2,"blue");
	cout << endl;
	return 0;
}

