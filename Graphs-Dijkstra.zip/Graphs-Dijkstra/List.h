#ifndef LIST_H
#define LIST_H

#include<cstddef>
#include<cstdlib>
#include <iostream>
#include <string>
using namespace std;
//This is a class for creating one node at a time for singly linked lists
class Node
{
public:
	//This is a class for creating one node at a time for singly linked lists
	Node();
	Node(string);
	Node(string,int);

	string data;
	int weight;
	int distance;
	bool over;
	Node* pre;
	Node* next;
};

//This is a class for creating singly linked list
class List
{
public:
	List();
	Node* head;
	int length_of_list;

};



#endif
