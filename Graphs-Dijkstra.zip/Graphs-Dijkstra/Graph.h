#ifndef GRAPH_H
#define GRAPH_H

#include <string>
#include <vector>
#include "List.h"
#include <tr1/unordered_map>
using namespace std;

class Vertex
{
	string data;
	int weight;
	int distance;
	int pre;
};

class Graph
{
public:
	bool isUndirected;
	int num_of_vertices;
	int num_of_edges;
	vector<Node*> ajdList;
	vector<string> vertexList;

	Graph();
	Graph(string,vector<string>,bool); //Constructor that takes in a file input and constructs a graph
	void AddEdgeToGraph(int,int,int);	//Adds an edge to the graph
	void AddVertexToGraph(string);	//Adds an vertex to the graph
	bool VertexSearch(string);	//Searches for a specified vertex in the graph
	Node* GetNode(string);	// Retrieves a vertex from the graph
	void EdgeRemoval(string, string);	//Deletes an edge from the graph
	void VertexRemoval(string);	//deleles a vertex and all its associated edges from the graph
	void CreateDotFile(Graph*, FILE*, bool);	//Creates a dot file
	void FindShortestPath_Dijkstra(string);	//Finds shortes path
	int weightRetrieval(Node*, Node*);	//Returns the weight betwwen 2 vertices
	void GraphRelax(Node*, Node*);	//Updates the graph
	void GraphUpdate(string, int, Node*);	//Updates the graph references
	Node* FindMinNode();	//Finds minimum node distance in graph
	void GraphInitialization();	//Initialzes the graph
	void ShortestDistanceDisplay(int, string);	//Displays shortes distance to all nodes from src vertes
	void ShortestPathDisplay(int,string);	//DIsplayst the shortes path
	std::tr1::unordered_map<string,string> ShortestPathRetrieval(string, string); //Returns a map of edges specifying a path from src to desst
	void CreateColoredDotFile(Graph*, FILE*,std::tr1::unordered_map<string, string>,string);	//Creates colored dot files for Test case 11 and 12
};
#endif

